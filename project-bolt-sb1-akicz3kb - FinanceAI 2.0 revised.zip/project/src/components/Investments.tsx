import React, { useState } from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  DollarSign, 
  TrendingUp, 
  AlertCircle,
  PieChart,
  Edit,
  Plus
} from 'lucide-react';
import CategoryBreakdown from './CategoryBreakdown';
import { useBankData } from './BankDataContext';

const Investments = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('Month');
  const [selectedView, setSelectedView] = useState('overview');
  const [selectedInvestment, setSelectedInvestment] = useState<string | null>(null);
  
  const { bankData } = useBankData();

  // Calculate portfolio value
  const portfolioValue = bankData.investments.reduce((sum, investment) => sum + investment.value, 0);
  
  // Mock data for portfolio change
  const portfolioChange = 1250.75;
  const portfolioChangePercent = 4.2;

  const timeframes = ['Week', 'Month', 'Quarter', 'Year', 'All'];
  
  const views = [
    { id: 'overview', label: 'Overview', icon: PieChart },
    { id: 'performance', label: 'Performance', icon: TrendingUp },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (selectedInvestment) {
    return (
      <CategoryBreakdown 
        category={selectedInvestment} 
        onBack={() => setSelectedInvestment(null)}
        type="investment"
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Investments</h1>
        
        <div className="flex items-center space-x-4 mt-4 md:mt-0">
          <div className="flex p-1 bg-gray-100 rounded-lg">
            {timeframes.map((timeframe) => (
              <button
                key={timeframe}
                onClick={() => setSelectedTimeframe(timeframe)}
                className={`px-3 py-1 rounded-md text-sm ${
                  selectedTimeframe === timeframe
                    ? 'bg-white shadow-sm font-medium'
                    : 'hover:bg-gray-200'
                }`}
              >
                {timeframe}
              </button>
            ))}
          </div>
          
          <div className="hidden md:flex p-1 bg-gray-100 rounded-lg">
            {views.map((view) => {
              const IconComponent = view.icon;
              return (
                <button
                  key={view.id}
                  onClick={() => setSelectedView(view.id)}
                  className={`flex items-center space-x-1 px-3 py-1 rounded-md ${
                    selectedView === view.id
                      ? 'bg-white shadow-sm'
                      : 'hover:bg-gray-200'
                  }`}
                >
                  <IconComponent size={16} />
                  <span>{view.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-sm font-medium text-gray-500">Portfolio Value</p>
          <p className="text-3xl font-bold text-gray-800 mt-1">{formatCurrency(portfolioValue)}</p>
          <div className="mt-2 flex items-center text-sm">
            {portfolioChange >= 0 ? (
              <>
                <ArrowUpRight className="text-green-500 mr-1" size={16} />
                <span className="text-green-500 font-medium">+{formatCurrency(portfolioChange)}</span>
              </>
            ) : (
              <>
                <ArrowDownRight className="text-red-500 mr-1" size={16} />
                <span className="text-red-500 font-medium">{formatCurrency(portfolioChange)}</span>
              </>
            )}
            <span className="text-gray-500 ml-1">({portfolioChangePercent}%)</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-sm font-medium text-gray-500">Risk Level</p>
          <p className="text-3xl font-bold text-gray-800 mt-1">Moderate</p>
          <div className="mt-2 flex items-center text-sm">
            <span className="text-gray-500">Balanced growth and stability</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-sm font-medium text-gray-500">Expected Annual Return</p>
          <p className="text-3xl font-bold text-gray-800 mt-1">7-9%</p>
          <div className="mt-2 flex items-center text-sm">
            <span className="text-gray-500">Based on your current allocation</span>
          </div>
        </div>
      </div>
      
      {/* Asset Allocation */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">Asset Allocation</h2>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              {/* This would be a chart in a real app */}
              <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                <PieChart size={100} className="text-gray-400" />
              </div>
            </div>
            
            <div>
              <div className="space-y-4">
                {bankData.assetAllocations.map((asset, index) => (
                  <div 
                    key={index}
                    className="cursor-pointer hover:bg-gray-50 p-2 rounded-lg"
                    onClick={() => setSelectedInvestment(asset.category)}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium text-gray-800">{asset.category}</span>
                      <div className="flex items-center">
                        <span className="font-medium text-gray-800">{asset.percentage}%</span>
                        <span className="text-gray-500 ml-2">{formatCurrency(asset.value)}</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`${
                          asset.category === 'Stocks' ? 'bg-blue-600' :
                          asset.category === 'Bonds' ? 'bg-green-600' :
                          asset.category === 'Cash' ? 'bg-yellow-600' : 'bg-purple-600'
                        } h-2 rounded-full`} 
                        style={{ width: `${asset.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
              
              <button className="mt-6 flex items-center text-indigo-600 font-medium hover:text-indigo-800">
                <Edit size={16} className="mr-1" />
                Adjust Target Allocation
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Investment Holdings */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Investment Holdings</h2>
          <button className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-800">
            <Plus size={16} />
            <span>Add Investment</span>
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ticker</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Shares</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Change</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Allocation</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {bankData.investments.map((investment, index) => (
                <tr 
                  key={index} 
                  className="hover:bg-gray-50 cursor-pointer"
                  onClick={() => setSelectedInvestment(investment.name)}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{investment.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{investment.ticker}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">
                    {investment.shares}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">
                    {formatCurrency(investment.price)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {formatCurrency(investment.value)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="flex items-center justify-end text-sm">
                      {investment.change >= 0 ? (
                        <span className="text-green-500">+{investment.change}%</span>
                      ) : (
                        <span className="text-red-500">{investment.change}%</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">
                    {((investment.value / portfolioValue) * 100).toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Investments;