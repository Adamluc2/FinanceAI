import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  Filter, 
  BarChart3, 
  PieChart,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Download
} from 'lucide-react';

interface Transaction {
  id: number;
  date: string;
  description: string;
  amount: number;
  category: string;
  account: string;
}

interface CategoryBreakdownProps {
  category: string;
  onBack: () => void;
  type: 'spending' | 'income' | 'budget' | 'goal' | 'investment' | 'insight';
}

const CategoryBreakdown: React.FC<CategoryBreakdownProps> = ({ category, onBack, type }) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('month');
  const [selectedView, setSelectedView] = useState('list');

  // Mock data for transactions
  const transactions: Transaction[] = [
    { 
      id: 1, 
      date: '2025-04-22', 
      description: 'Whole Foods Market', 
      amount: -78.45, 
      category: 'Groceries', 
      account: 'Chase Checking'
    },
    { 
      id: 2, 
      date: '2025-04-20', 
      description: 'Trader Joe\'s', 
      amount: -42.67, 
      category: 'Groceries', 
      account: 'Amex Credit Card'
    },
    { 
      id: 3, 
      date: '2025-04-18', 
      description: 'Safeway', 
      amount: -65.32, 
      category: 'Groceries', 
      account: 'Chase Checking'
    },
    { 
      id: 4, 
      date: '2025-04-15', 
      description: 'Costco', 
      amount: -145.78, 
      category: 'Groceries', 
      account: 'Amex Credit Card'
    },
    { 
      id: 5, 
      date: '2025-04-12', 
      description: 'Farmer\'s Market', 
      amount: -32.50, 
      category: 'Groceries', 
      account: 'Chase Checking'
    },
    { 
      id: 6, 
      date: '2025-04-10', 
      description: 'Whole Foods Market', 
      amount: -56.78, 
      category: 'Groceries', 
      account: 'Chase Checking'
    },
    { 
      id: 7, 
      date: '2025-04-08', 
      description: 'Trader Joe\'s', 
      amount: -38.92, 
      category: 'Groceries', 
      account: 'Amex Credit Card'
    },
    { 
      id: 8, 
      date: '2025-04-05', 
      description: 'Safeway', 
      amount: -72.45, 
      category: 'Groceries', 
      account: 'Chase Checking'
    },
    { 
      id: 9, 
      date: '2025-04-02', 
      description: 'Whole Foods Market', 
      amount: -48.32, 
      category: 'Groceries', 
      account: 'Amex Credit Card'
    },
    { 
      id: 10, 
      date: '2025-04-01', 
      description: 'Costco', 
      amount: -165.89, 
      category: 'Groceries', 
      account: 'Chase Checking'
    },
  ];

  // Filter transactions based on category
  const filteredTransactions = transactions.filter(t => 
    t.category.toLowerCase() === category.toLowerCase()
  );

  // Calculate total spent
  const totalSpent = filteredTransactions.reduce((sum, t) => sum + Math.abs(t.amount), 0);
  
  // Calculate average transaction
  const averageTransaction = totalSpent / filteredTransactions.length;
  
  // Calculate daily spending
  const dailySpending = totalSpent / 30; // Assuming a month

  const timeframes = [
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: '3months', label: 'Last 3 Months' },
    { value: 'year', label: 'This Year' },
  ];

  const views = [
    { id: 'list', label: 'List', icon: Filter },
    { id: 'chart', label: 'Chart', icon: BarChart3 },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Get title and description based on type
  const getTypeInfo = () => {
    switch (type) {
      case 'spending':
        return {
          title: `${category} Spending`,
          description: `Detailed breakdown of your ${category.toLowerCase()} spending`
        };
      case 'income':
        return {
          title: `${category} Income`,
          description: `Detailed breakdown of your ${category.toLowerCase()} income`
        };
      case 'budget':
        return {
          title: `${category} Budget`,
          description: `Detailed breakdown of your ${category.toLowerCase()} budget`
        };
      case 'goal':
        return {
          title: `${category} Goal`,
          description: `Detailed breakdown of your ${category.toLowerCase()} goal progress`
        };
      case 'investment':
        return {
          title: `${category} Investments`,
          description: `Detailed breakdown of your ${category.toLowerCase()} investments`
        };
      case 'insight':
        return {
          title: `${category} Insights`,
          description: `Detailed breakdown of your ${category.toLowerCase()} financial insights`
        };
      default:
        return {
          title: category,
          description: `Detailed breakdown of ${category.toLowerCase()}`
        };
    }
  };

  const typeInfo = getTypeInfo();

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <button 
          onClick={onBack}
          className="p-2 mr-3 rounded-full hover:bg-gray-100"
        >
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{typeInfo.title}</h1>
          <p className="text-gray-500">{typeInfo.description}</p>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 bg-indigo-100 rounded-full">
              <DollarSign size={20} className="text-indigo-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">Total {type === 'income' ? 'Income' : 'Spent'}</h2>
          </div>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(totalSpent)}</p>
          <p className="text-gray-500 mt-1">This {selectedTimeframe}</p>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 bg-green-100 rounded-full">
              <TrendingUp size={20} className="text-green-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">Average Transaction</h2>
          </div>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(averageTransaction)}</p>
          <p className="text-gray-500 mt-1">Per transaction</p>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 bg-blue-100 rounded-full">
              <Calendar size={20} className="text-blue-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">Daily Average</h2>
          </div>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(dailySpending)}</p>
          <p className="text-gray-500 mt-1">Per day</p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-4">
            <select
              className="border border-gray-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
            >
              {timeframes.map((timeframe) => (
                <option key={timeframe.value} value={timeframe.value}>
                  {timeframe.label}
                </option>
              ))}
            </select>
            
            <div className="flex p-1 bg-gray-100 rounded-lg">
              {views.map((view) => {
                const IconComponent = view.icon;
                return (
                  <button
                    key={view.id}
                    onClick={() => setSelectedView(view.id)}
                    className={`flex items-center space-x-1 px-3 py-1 rounded-md ${
                      selectedView === view.id
                        ? 'bg-white shadow-sm'
                        : 'hover:bg-gray-200'
                    }`}
                  >
                    <IconComponent size={16} />
                    <span>{view.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
          
          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download size={16} className="text-gray-600" />
            <span>Export Data</span>
          </button>
        </div>
      </div>
      
      {/* Transactions or Chart */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">
            {selectedView === 'list' ? 'Transactions' : 'Spending Trend'}
          </h2>
        </div>
        
        {selectedView === 'list' ? (
          <div className="divide-y divide-gray-200">
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map((transaction) => (
                <div key={transaction.id} className="p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">{transaction.description}</p>
                      <div className="flex items-center text-sm text-gray-500">
                        <span>{formatDate(transaction.date)}</span>
                        <span className="mx-1">•</span>
                        <span>{transaction.account}</span>
                      </div>
                    </div>
                    <p className="font-semibold text-red-600">
                      {formatCurrency(transaction.amount)}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center">
                <p className="text-gray-500">No transactions found for this category.</p>
              </div>
            )}
          </div>
        ) : (
          <div className="p-6">
            {/* This would be a chart in a real app */}
            <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
              <BarChart3 size={100} className="text-gray-400" />
              <p className="ml-4 text-gray-500">Spending trend visualization would appear here</p>
            </div>
          </div>
        )}
      </div>
      
      {/* AI Insights */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">AI Insights</h2>
        
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-start">
              <div className="p-2 bg-blue-100 rounded-full mr-3">
                <TrendingUp size={18} className="text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-800">Spending Pattern</p>
                <p className="text-gray-600 mt-1">
                  Your {category.toLowerCase()} spending is 15% higher on weekends. Consider planning your shopping on weekdays to potentially save money.
                </p>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-start">
              <div className="p-2 bg-green-100 rounded-full mr-3">
                <DollarSign size={18} className="text-green-600" />
              </div>
              <div>
                <p className="font-medium text-gray-800">Savings Opportunity</p>
                <p className="text-gray-600 mt-1">
                  You could save approximately $45 per month on {category.toLowerCase()} by shopping at Trader Joe's more frequently based on your transaction history.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryBreakdown;