import React, { useState } from 'react';
import { X, Calendar, DollarSign } from 'lucide-react';
import { useBankData } from '../BankDataContext';

interface AddTransactionModalProps {
  onClose: () => void;
}

const AddTransactionModal: React.FC<AddTransactionModalProps> = ({ onClose }) => {
  const { bankData, addTransaction } = useBankData();
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState('');
  const [account, setAccount] = useState('');
  const [isExpense, setIsExpense] = useState(true);
  const [error, setError] = useState('');

  // Common categories
  const categories = [
    'Groceries',
    'Dining',
    'Shopping',
    'Entertainment',
    'Housing',
    'Transportation',
    'Utilities',
    'Healthcare',
    'Education',
    'Travel',
    'Personal Care',
    'Gifts',
    'Income',
    'Transfer',
    'Other'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate inputs
    if (!description.trim()) {
      setError('Description is required');
      return;
    }
    
    if (!account) {
      setError('Please select an account');
      return;
    }
    
    if (!category) {
      setError('Please select a category');
      return;
    }
    
    const amountValue = parseFloat(amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      setError('Please enter a valid amount greater than zero');
      return;
    }
    
    // Create new transaction
    const newTransaction = {
      id: `manual-tx-${Date.now()}`,
      date,
      description: description.trim(),
      amount: isExpense ? -amountValue : amountValue,
      category,
      account,
      pending: false
    };
    
    // Add transaction to context
    addTransaction(newTransaction);
    
    // Close modal
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-md w-full overflow-hidden">
        <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
          <div>
            <h3 className="text-lg font-semibold">Add New Transaction</h3>
            <p className="text-sm opacity-90">Enter transaction details</p>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-indigo-500 transition-colors"
          >
            <X size={20} className="text-white" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md">
              {error}
            </div>
          )}
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <input 
              type="text" 
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g., Grocery shopping"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Transaction Type</label>
            <div className="flex p-1 bg-gray-100 rounded-lg">
              <button
                type="button"
                onClick={() => setIsExpense(true)}
                className={`flex-1 py-2 rounded-md ${
                  isExpense ? 'bg-white shadow-sm font-medium' : 'hover:bg-gray-200'
                }`}
              >
                Expense
              </button>
              <button
                type="button"
                onClick={() => setIsExpense(false)}
                className={`flex-1 py-2 rounded-md ${
                  !isExpense ? 'bg-white shadow-sm font-medium' : 'hover:bg-gray-200'
                }`}
              >
                Income
              </button>
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500">$</span>
              </div>
              <input 
                type="text" 
                className="w-full pl-8 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="0.00"
                value={amount}
                onChange={(e) => {
                  // Allow only numbers and decimal point
                  const value = e.target.value;
                  if (/^\d*\.?\d*$/.test(value)) {
                    setAmount(value);
                  }
                }}
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar size={16} className="text-gray-500" />
              </div>
              <input 
                type="date" 
                className="w-full pl-10 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Account</label>
            <select
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={account}
              onChange={(e) => setAccount(e.target.value)}
            >
              <option value="">Select an account</option>
              {bankData.accounts.map((acc) => (
                <option key={acc.id} value={acc.name}>
                  {acc.name} ({acc.institution})
                </option>
              ))}
            </select>
            {bankData.accounts.length === 0 && (
              <p className="text-sm text-yellow-600 mt-1">
                You need to add an account first before adding transactions.
              </p>
            )}
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">Select a category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex justify-end space-x-3">
            <button 
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            
            <button 
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              disabled={bankData.accounts.length === 0}
            >
              Add Transaction
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddTransactionModal;