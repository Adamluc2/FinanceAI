import React, { useState } from 'react';
import { X, DollarSign, ShoppingBag, Coffee, Home, Car, Utensils, Wifi, ShoppingCart } from 'lucide-react';
import { useBankData } from '../BankDataContext';

interface AddBudgetModalProps {
  onClose: () => void;
}

const AddBudgetModal: React.FC<AddBudgetModalProps> = ({ onClose }) => {
  const { addBudget, bankData } = useBankData();
  const [category, setCategory] = useState('');
  const [customCategory, setCustomCategory] = useState('');
  const [budgetAmount, setBudgetAmount] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('ShoppingBag');
  const [selectedColor, setSelectedColor] = useState('blue');
  const [error, setError] = useState('');

  // Common categories
  const categories = [
    'Groceries',
    'Dining',
    'Shopping',
    'Entertainment',
    'Housing',
    'Transportation',
    'Utilities',
    'Healthcare',
    'Education',
    'Travel',
    'Personal Care',
    'Gifts',
    'Other'
  ];

  // Available icons
  const icons = [
    { name: 'ShoppingBag', component: ShoppingBag },
    { name: 'Coffee', component: Coffee },
    { name: 'Home', component: Home },
    { name: 'Car', component: Car },
    { name: 'Utensils', component: Utensils },
    { name: 'Wifi', component: Wifi },
    { name: 'ShoppingCart', component: ShoppingCart },
    { name: 'DollarSign', component: DollarSign },
  ];

  // Available colors
  const colors = [
    'blue',
    'green',
    'red',
    'yellow',
    'purple',
    'pink',
    'indigo',
    'orange'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate inputs
    const finalCategory = category === 'custom' ? customCategory : category;
    
    if (!finalCategory.trim()) {
      setError('Category name is required');
      return;
    }
    
    // Check if category already exists
    const existingCategory = bankData.budgets.find(b => 
      b.category.toLowerCase() === finalCategory.toLowerCase()
    );
    
    if (existingCategory) {
      setError('This category already exists');
      return;
    }
    
    const budgetValue = parseFloat(budgetAmount);
    if (isNaN(budgetValue) || budgetValue <= 0) {
      setError('Please enter a valid budget amount greater than zero');
      return;
    }
    
    // Create new budget
    const newBudget = {
      category: finalCategory.trim(),
      budgeted: budgetValue,
      spent: 0,
      percentage: 0,
      icon: selectedIcon,
      color: selectedColor
    };
    
    // Add budget to context
    addBudget(newBudget);
    
    // Close modal
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-md w-full overflow-hidden">
        <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
          <div>
            <h3 className="text-lg font-semibold">Add Budget Category</h3>
            <p className="text-sm opacity-90">Set up a new budget category</p>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-indigo-500 transition-colors"
          >
            <X size={20} className="text-white" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md">
              {error}
            </div>
          )}
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">Select a category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
              <option value="custom">Custom category...</option>
            </select>
          </div>
          
          {category === 'custom' && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Custom Category Name</label>
              <input 
                type="text" 
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="e.g., Subscriptions"
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
              />
            </div>
          )}
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Budget Amount</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500">$</span>
              </div>
              <input 
                type="text" 
                className="w-full pl-8 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="0.00"
                value={budgetAmount}
                onChange={(e) => {
                  // Allow only numbers and decimal point
                  const value = e.target.value;
                  if (/^\d*\.?\d*$/.test(value)) {
                    setBudgetAmount(value);
                  }
                }}
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Icon</label>
            <div className="grid grid-cols-4 gap-2">
              {icons.map((icon) => {
                const IconComponent = icon.component;
                return (
                  <button
                    key={icon.name}
                    type="button"
                    onClick={() => setSelectedIcon(icon.name)}
                    className={`p-3 border rounded-lg flex items-center justify-center ${
                      selectedIcon === icon.name 
                        ? 'border-indigo-600 bg-indigo-50' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <IconComponent size={20} className="text-gray-700" />
                  </button>
                );
              })}
            </div>
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Color</label>
            <div className="grid grid-cols-4 gap-2">
              {colors.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setSelectedColor(color)}
                  className={`h-10 rounded-lg border ${
                    selectedColor === color 
                      ? 'border-gray-800 ring-2 ring-gray-400' 
                      : 'border-gray-300'
                  }`}
                  style={{ backgroundColor: `var(--tw-${color}-500)` }}
                >
                  <span className="sr-only">{color}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex justify-end space-x-3">
            <button 
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            
            <button 
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Add Budget
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddBudgetModal;