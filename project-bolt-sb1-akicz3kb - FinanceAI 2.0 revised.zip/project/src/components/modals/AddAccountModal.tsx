import React, { useState } from 'react';
import { X, Building, CreditCard, TrendingUp, DollarSign } from 'lucide-react';
import { useBankData } from '../BankDataContext';

interface AddAccountModalProps {
  onClose: () => void;
}

const AddAccountModal: React.FC<AddAccountModalProps> = ({ onClose }) => {
  const { addAccount } = useBankData();
  const [accountName, setAccountName] = useState('');
  const [accountType, setAccountType] = useState<'checking' | 'savings' | 'credit' | 'investment'>('checking');
  const [balance, setBalance] = useState('');
  const [institution, setInstitution] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate inputs
    if (!accountName.trim()) {
      setError('Account name is required');
      return;
    }
    
    if (!institution.trim()) {
      setError('Institution name is required');
      return;
    }
    
    const balanceValue = parseFloat(balance);
    if (isNaN(balanceValue)) {
      setError('Please enter a valid balance amount');
      return;
    }
    
    // Create new account
    const newAccount = {
      id: `manual-${Date.now()}`,
      name: accountName.trim(),
      type: accountType,
      balance: balanceValue,
      institution: institution.trim(),
      lastUpdated: new Date().toISOString()
    };
    
    // Add account to context
    addAccount(newAccount);
    
    // Close modal
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-md w-full overflow-hidden">
        <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
          <div>
            <h3 className="text-lg font-semibold">Add New Account</h3>
            <p className="text-sm opacity-90">Enter your account details</p>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-indigo-500 transition-colors"
          >
            <X size={20} className="text-white" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md">
              {error}
            </div>
          )}
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Account Name</label>
            <input 
              type="text" 
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g., My Checking Account"
              value={accountName}
              onChange={(e) => setAccountName(e.target.value)}
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Institution</label>
            <input 
              type="text" 
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g., Chase Bank"
              value={institution}
              onChange={(e) => setInstitution(e.target.value)}
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Account Type</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setAccountType('checking')}
                className={`flex items-center p-3 border rounded-lg ${
                  accountType === 'checking' 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="p-2 bg-blue-100 rounded-lg mr-3">
                  <Building size={20} className="text-blue-600" />
                </div>
                <span className="font-medium">Checking</span>
              </button>
              
              <button
                type="button"
                onClick={() => setAccountType('savings')}
                className={`flex items-center p-3 border rounded-lg ${
                  accountType === 'savings' 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="p-2 bg-blue-100 rounded-lg mr-3">
                  <DollarSign size={20} className="text-blue-600" />
                </div>
                <span className="font-medium">Savings</span>
              </button>
              
              <button
                type="button"
                onClick={() => setAccountType('credit')}
                className={`flex items-center p-3 border rounded-lg ${
                  accountType === 'credit' 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="p-2 bg-red-100 rounded-lg mr-3">
                  <CreditCard size={20} className="text-red-600" />
                </div>
                <span className="font-medium">Credit</span>
              </button>
              
              <button
                type="button"
                onClick={() => setAccountType('investment')}
                className={`flex items-center p-3 border rounded-lg ${
                  accountType === 'investment' 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="p-2 bg-green-100 rounded-lg mr-3">
                  <TrendingUp size={20} className="text-green-600" />
                </div>
                <span className="font-medium">Investment</span>
              </button>
            </div>
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Current Balance</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500">$</span>
              </div>
              <input 
                type="text" 
                className="w-full pl-8 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="0.00"
                value={balance}
                onChange={(e) => {
                  // Allow only numbers and decimal point
                  const value = e.target.value;
                  if (/^-?\d*\.?\d*$/.test(value)) {
                    setBalance(value);
                  }
                }}
              />
            </div>
            {accountType === 'credit' && (
              <p className="text-sm text-gray-500 mt-1">
                For credit cards, enter a negative balance if you owe money (e.g., -500 for a $500 balance).
              </p>
            )}
          </div>
          
          <div className="flex justify-end space-x-3">
            <button 
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            
            <button 
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Add Account
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddAccountModal;