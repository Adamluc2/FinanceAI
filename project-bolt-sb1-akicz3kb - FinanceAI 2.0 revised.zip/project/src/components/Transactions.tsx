import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  ShoppingBag, 
  Coffee, 
  Home, 
  Car, 
  Utensils, 
  Wifi, 
  ShoppingCart,
  DollarSign
} from 'lucide-react';
import CategoryBreakdown from './CategoryBreakdown';
import { useBankData } from './BankDataContext';

const Transactions = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState('month');
  const [categoryDetail, setCategoryDetail] = useState<string | null>(null);
  
  const { bankData } = useBankData();

  const categories = [
    { name: 'all', label: 'All Categories' },
    { name: 'groceries', label: 'Groceries', icon: ShoppingCart },
    { name: 'dining', label: 'Dining', icon: Utensils },
    { name: 'shopping', label: 'Shopping', icon: ShoppingBag },
    { name: 'entertainment', label: 'Entertainment', icon: Wifi },
    { name: 'housing', label: 'Housing', icon: Home },
    { name: 'transportation', label: 'Transportation', icon: Car },
    { name: 'income', label: 'Income', icon: DollarSign },
  ];

  const timeframes = [
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: '3months', label: 'Last 3 Months' },
    { value: 'year', label: 'This Year' },
  ];

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'groceries':
        return <ShoppingCart size={18} className="text-green-600" />;
      case 'dining':
        return <Utensils size={18} className="text-orange-600" />;
      case 'entertainment':
        return <Wifi size={18} className="text-purple-600" />;
      case 'transportation':
        return <Car size={18} className="text-blue-600" />;
      case 'shopping':
        return <ShoppingBag size={18} className="text-pink-600" />;
      case 'housing':
        return <Home size={18} className="text-indigo-600" />;
      case 'utilities':
        return <Wifi size={18} className="text-yellow-600" />;
      case 'income':
        return <DollarSign size={18} className="text-green-600" />;
      default:
        return <ShoppingBag size={18} className="text-gray-600" />;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const filteredTransactions = bankData.transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          transaction.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || 
                           transaction.category.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  if (categoryDetail) {
    return (
      <CategoryBreakdown 
        category={categoryDetail} 
        onBack={() => setCategoryDetail(null)}
        type="spending"
      />
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Transactions</h1>
      
      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-col md:flex-row md:items-center md:space-x-4 space-y-4 md:space-y-0">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search transactions..."
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex space-x-2">
            <select
              className="border border-gray-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
            >
              {timeframes.map((timeframe) => (
                <option key={timeframe.value} value={timeframe.value}>
                  {timeframe.label}
                </option>
              ))}
            </select>
            
            <button className="flex items-center space-x-1 px-3 py-2 border border-gray-300 rounded-lg bg-white hover:bg-gray-50">
              <Filter size={18} className="text-gray-600" />
              <span>More Filters</span>
            </button>
          </div>
        </div>
        
        {/* Category Pills */}
        <div className="mt-4 flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category.name}
              onClick={() => {
                if (category.name !== 'all') {
                  setCategoryDetail(category.label);
                } else {
                  setSelectedCategory(category.name);
                }
              }}
              className={`px-3 py-1 rounded-full text-sm font-medium ${
                selectedCategory === category.name
                  ? 'bg-indigo-100 text-indigo-800'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Transactions List */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">Recent Transactions</h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {filteredTransactions.length > 0 ? (
            filteredTransactions.map((transaction) => (
              <div 
                key={transaction.id} 
                className="p-4 hover:bg-gray-50 cursor-pointer"
                onClick={() => setCategoryDetail(transaction.category)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-full bg-gray-100">
                      {getCategoryIcon(transaction.category)}
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{transaction.description}</p>
                      <div className="flex items-center text-sm text-gray-500">
                        <span>{formatDate(transaction.date)}</span>
                        <span className="mx-1">•</span>
                        <span>{transaction.category}</span>
                        <span className="mx-1">•</span>
                        <span>{transaction.account}</span>
                      </div>
                    </div>
                  </div>
                  <p className={`font-semibold ${transaction.amount < 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {formatCurrency(transaction.amount)}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center">
              <p className="text-gray-500">No transactions found matching your filters.</p>
            </div>
          )}
        </div>
        
        {filteredTransactions.length > 0 && (
          <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-center">
            <button className="text-indigo-600 font-medium hover:text-indigo-800">
              Load more transactions
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Transactions;