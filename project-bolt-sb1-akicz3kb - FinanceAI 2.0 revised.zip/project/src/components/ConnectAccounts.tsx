import React, { useState } from 'react';
import { 
  Landmark, 
  CreditCard, 
  Lock, 
  CheckCircle, 
  AlertCircle,
  DollarSign,
  Building,
  CreditCard as CreditCardIcon,
  Wallet,
  User,
  Eye,
  EyeOff,
  Loader,
  Shield,
  Check,
  TrendingUp,
  ChevronRight
} from 'lucide-react';
import { useBankData } from './BankDataContext';

interface BankPopup {
  bankId: string;
  name: string;
}

const ConnectAccounts = ({ onConnect }: { onConnect: () => void }) => {
  const [step, setStep] = useState(1);
  const [selectedBanks, setSelectedBanks] = useState<string[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('us');
  const [showLoginPopup, setShowLoginPopup] = useState<BankPopup | null>(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [connectedBanks, setConnectedBanks] = useState<string[]>([]);
  const [connectionSuccess, setConnectionSuccess] = useState(false);
  const [useManualSetup, setUseManualSetup] = useState(false);
  
  const { connectBank, setManualSetup } = useBankData();

  // Mock bank data
  const usBanks = [
    { id: 'chase', name: 'Chase', logo: 'chase', popular: true },
    { id: 'bofa', name: 'Bank of America', logo: 'bofa', popular: true },
    { id: 'wells', name: 'Wells Fargo', logo: 'wells', popular: true },
    { id: 'citi', name: 'Citibank', logo: 'citi', popular: true },
    { id: 'capital', name: 'Capital One', logo: 'capital', popular: true },
    { id: 'amex', name: 'American Express', logo: 'amex', popular: false },
    { id: 'discover', name: 'Discover', logo: 'discover', popular: false },
    { id: 'usbank', name: 'US Bank', logo: 'usbank', popular: false },
    { id: 'pnc', name: 'PNC Bank', logo: 'pnc', popular: false },
    { id: 'td', name: 'TD Bank', logo: 'td', popular: false },
    { id: 'vanguard', name: 'Vanguard', logo: 'vanguard', popular: false },
  ];

  const canadianBanks = [
    { id: 'rbc', name: 'Royal Bank of Canada', logo: 'rbc', popular: true },
    { id: 'td-canada', name: 'TD Canada Trust', logo: 'td-canada', popular: true },
    { id: 'scotiabank', name: 'Scotiabank', logo: 'scotiabank', popular: true },
    { id: 'bmo', name: 'BMO Bank of Montreal', logo: 'bmo', popular: true },
    { id: 'cibc', name: 'CIBC', logo: 'cibc', popular: true },
    { id: 'servus', name: 'Servus Credit Union', logo: 'servus', popular: true },
    { id: 'national', name: 'National Bank', logo: 'national', popular: false },
    { id: 'desjardins', name: 'Desjardins', logo: 'desjardins', popular: false },
    { id: 'tangerine', name: 'Tangerine', logo: 'tangerine', popular: false },
    { id: 'hsbc-canada', name: 'HSBC Canada', logo: 'hsbc-canada', popular: false },
    { id: 'simplii', name: 'Simplii Financial', logo: 'simplii', popular: false },
  ];

  const banks = selectedCountry === 'us' ? usBanks : canadianBanks;

  const toggleBank = (bankId: string) => {
    if (selectedBanks.includes(bankId)) {
      setSelectedBanks(selectedBanks.filter(id => id !== bankId));
    } else {
      setSelectedBanks([...selectedBanks, bankId]);
    }
  };

  const handleConnect = () => {
    if (useManualSetup) {
      // Set manual setup mode in context
      setManualSetup(true);
      
      // Simulate connection process
      setIsConnecting(true);
      setTimeout(() => {
        setIsConnecting(false);
        setIsConnected(true);
        
        // Move to success step
        setStep(3);
        
        // After showing success message, call the onConnect callback
        setTimeout(() => {
          onConnect();
        }, 2000);
      }, 1500);
      
      return;
    }
    
    if (selectedBanks.length === 0) return;
    
    setIsConnecting(true);
    
    // Connect all banks to the context
    connectedBanks.forEach(bankId => {
      connectBank(bankId);
    });
    
    // Simulate connection process
    setTimeout(() => {
      setIsConnecting(false);
      setIsConnected(true);
      
      // Move to success step
      setStep(3);
      
      // After showing success message, call the onConnect callback
      setTimeout(() => {
        onConnect();
      }, 2000);
    }, 3000);
  };

  const getBankIcon = (bankId: string) => {
    switch (bankId) {
      case 'chase':
      case 'bofa':
      case 'wells':
      case 'citi':
      case 'usbank':
      case 'pnc':
      case 'td':
      case 'rbc':
      case 'td-canada':
      case 'scotiabank':
      case 'bmo':
      case 'cibc':
      case 'national':
      case 'desjardins':
      case 'hsbc-canada':
      case 'servus':
        return <Building size={24} className="text-blue-600" />;
      case 'capital':
      case 'amex':
      case 'discover':
      case 'tangerine':
      case 'simplii':
        return <CreditCardIcon size={24} className="text-purple-600" />;
      case 'vanguard':
        return <TrendingUp size={24} className="text-green-600" />;
      default:
        return <Landmark size={24} className="text-gray-600" />;
    }
  };

  const handleBankLogin = (bankId: string) => {
    const bank = banks.find(b => b.id === bankId);
    if (bank) {
      setShowLoginPopup({
        bankId: bank.id,
        name: bank.name
      });
      setConnectionSuccess(false);
      setLoginUsername('');
      setLoginPassword('');
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loginUsername || !loginPassword) return;
    
    setLoginLoading(true);
    
    // Simulate login process
    setTimeout(() => {
      setLoginLoading(false);
      setConnectionSuccess(true);
      
      // Add the bank to connected banks
      if (!connectedBanks.includes(showLoginPopup?.bankId || '')) {
        setConnectedBanks([...connectedBanks, showLoginPopup?.bankId || '']);
      }
      
      // Don't close the popup yet, show the success state
    }, 2000);
  };

  const handleClosePopup = () => {
    setShowLoginPopup(null);
    setConnectionSuccess(false);
  };

  const handleProceed = () => {
    // Connect the bank to the context
    if (showLoginPopup) {
      connectBank(showLoginPopup.bankId);
    }
    
    // Close the popup
    setShowLoginPopup(null);
    setConnectionSuccess(false);
    
    // Add the bank to selected banks if not already selected
    if (!selectedBanks.includes(showLoginPopup?.bankId || '')) {
      setSelectedBanks([...selectedBanks, showLoginPopup?.bankId || '']);
    }
  };

  const handleManualSetup = () => {
    setUseManualSetup(true);
    setStep(2);
  };

  return (
    <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg">
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="p-3 bg-indigo-100 rounded-full">
            <DollarSign size={32} className="text-indigo-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-gray-800">Welcome to FinanceAI</h1>
        <p className="text-gray-600 mt-2">
          Connect your accounts to get personalized financial insights and recommendations
        </p>
      </div>
      
      {/* Progress Steps */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 1 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            1
          </div>
          <div className={`w-12 h-1 ${step >= 2 ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 2 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            2
          </div>
          <div className={`w-12 h-1 ${step >= 3 ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 3 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            3
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6 md:p-8">
        {step === 1 && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Choose How to Set Up Your Account</h2>
            <p className="text-gray-600 mb-6">
              You can either connect your financial institutions securely or set up your accounts manually.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="border border-gray-300 rounded-lg p-6 hover:border-indigo-500 cursor-pointer transition-colors">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-blue-100 rounded-full mr-3">
                    <Building size={24} className="text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Connect Your Banks</h3>
                </div>
                <p className="text-gray-600 mb-4">
                  Securely connect your bank accounts to automatically import transactions and balances.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                    <span className="text-sm text-gray-600">Automatic transaction syncing</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                    <span className="text-sm text-gray-600">Real-time balance updates</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                    <span className="text-sm text-gray-600">Bank-level security</span>
                  </li>
                </ul>
                <button
                  onClick={() => setStep(2)}
                  className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  Connect Banks
                </button>
              </div>
              
              <div className="border border-gray-300 rounded-lg p-6 hover:border-indigo-500 cursor-pointer transition-colors">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-green-100 rounded-full mr-3">
                    <User size={24} className="text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Manual Setup</h3>
                </div>
                <p className="text-gray-600 mb-4">
                  Manually add your accounts and transactions without connecting to your banks.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                    <span className="text-sm text-gray-600">No bank credentials required</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                    <span className="text-sm text-gray-600">Complete privacy</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                    <span className="text-sm text-gray-600">Full control over your data</span>
                  </li>
                </ul>
                <button
                  onClick={handleManualSetup}
                  className="w-full px-4 py-2 border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50"
                >
                  Manual Setup
                </button>
              </div>
            </div>
            
            <div className="flex items-center p-4 bg-blue-50 rounded-lg">
              <Lock size={20} className="text-blue-600 mr-3" />
              <p className="text-sm text-blue-800">
                Your security is our priority. We use bank-level encryption and never store your credentials.
              </p>
            </div>
          </div>
        )}
        
        {step === 2 && !useManualSetup && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Select Your Financial Institutions</h2>
            <p className="text-gray-600 mb-6">
              Choose the banks and credit cards you want to connect. We'll securely access your transaction data to provide personalized insights.
            </p>
            
            {/* Country Selection */}
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Select Country</h3>
              <div className="flex space-x-4">
                <button
                  onClick={() => {
                    setSelectedCountry('us');
                    setSelectedBanks([]);
                  }}
                  className={`px-4 py-2 rounded-lg ${
                    selectedCountry === 'us' 
                      ? 'bg-indigo-100 text-indigo-800 border border-indigo-300' 
                      : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200'
                  }`}
                >
                  United States
                </button>
                <button
                  onClick={() => {
                    setSelectedCountry('ca');
                    setSelectedBanks([]);
                  }}
                  className={`px-4 py-2 rounded-lg ${
                    selectedCountry === 'ca' 
                      ? 'bg-indigo-100 text-indigo-800 border border-indigo-300' 
                      : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200'
                  }`}
                >
                  Canada
                </button>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Popular Banks</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {banks.filter(bank => bank.popular).map(bank => (
                  <button
                    key={bank.id}
                    onClick={() => toggleBank(bank.id)}
                    className={`flex items-center p-3 border rounded-lg ${
                      selectedBanks.includes(bank.id) 
                        ? 'border-indigo-600 bg-indigo-50' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <div className="p-2 bg-gray-100 rounded-lg mr-3">
                      {getBankIcon(bank.id)}
                    </div>
                    <span className="font-medium">{bank.name}</span>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Other Financial Institutions</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {banks.filter(bank => !bank.popular).map(bank => (
                  <button
                    key={bank.id}
                    onClick={() => toggleBank(bank.id)}
                    className={`flex items-center p-3 border rounded-lg ${
                      selectedBanks.includes(bank.id) 
                        ? 'border-indigo-600 bg-indigo-50' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <div className="p-2 bg-gray-100 rounded-lg mr-3">
                      {getBankIcon(bank.id)}
                    </div>
                    <span className="font-medium">{bank.name}</span>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex items-center p-4 bg-blue-50 rounded-lg mb-6">
              <Lock size={20} className="text-blue-600 mr-3" />
              <p className="text-sm text-blue-800">
                Your security is our priority. We use bank-level encryption and never store your credentials.
              </p>
            </div>
            
            <div className="flex justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-6 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
              >
                Back
              </button>
              
              <button
                onClick={() => setStep(2)}
                disabled={selectedBanks.length === 0}
                className={`px-6 py-2 rounded-lg font-medium ${
                  selectedBanks.length > 0
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                }`}
              >
                Continue
              </button>
            </div>
          </div>
        )}
        
        {step === 2 && useManualSetup && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Manual Setup</h2>
            <p className="text-gray-600 mb-6">
              You've chosen to set up your accounts manually. This gives you complete privacy and control over your financial data.
            </p>
            
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <h3 className="font-medium text-gray-800 mb-4">What to expect with manual setup:</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle size={18} className="text-green-600 mr-2 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-800">Add accounts yourself</p>
                    <p className="text-sm text-gray-600">You'll be able to add checking, savings, credit cards, and investment accounts manually.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <CheckCircle size={18} className="text-green-600 mr-2 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-800">Enter transactions manually</p>
                    <p className="text-sm text-gray-600">You'll need to add your income and expenses manually to track your spending.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <CheckCircle size={18} className="text-green-600 mr-2 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-800">Create budgets and goals</p>
                    <p className="text-sm text-gray-600">Set up custom budgets and financial goals to track your progress.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <CheckCircle size={18} className="text-green-600 mr-2 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-800">Complete privacy</p>
                    <p className="text-sm text-gray-600">Your financial data stays on your device and is never shared with any third parties.</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="flex items-center p-4 bg-yellow-50 rounded-lg mb-6">
              <AlertCircle size={20} className="text-yellow-600 mr-3" />
              <p className="text-sm text-yellow-800">
                Note: You can always connect your bank accounts later if you change your mind.
              </p>
            </div>
            
            <div className="flex justify-between">
              <button
                onClick={() => {
                  setUseManualSetup(false);
                  setStep(1);
                }}
                className="px-6 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
              >
                Back
              </button>
              
              <button
                onClick={handleConnect}
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-medium"
              >
                Continue to Dashboard
              </button>
            </div>
          </div>
        )}
        
        {step === 2 && !useManualSetup && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Connect Your Accounts</h2>
            <p className="text-gray-600 mb-6">
              You're about to securely connect the following financial institutions:
            </p>
            
            <div className="mb-6">
              <div className="space-y-3">
                {selectedBanks.map(bankId => {
                  const bank = banks.find(b => b.id === bankId);
                  const isConnected = connectedBanks.includes(bankId);
                  
                  return (
                    <div key={bankId} className="flex items-center justify-between p-3 border border-gray-300 rounded-lg">
                      <div className="flex items-center">
                        <div className="p-2 bg-gray-100 rounded-lg mr-3">
                          {getBankIcon(bankId)}
                        </div>
                        <span className="font-medium">{bank?.name}</span>
                      </div>
                      {isConnected ? (
                        <div className="flex items-center text-green-600">
                          <Check size={16} className="mr-1" />
                          <span className="font-medium">Connected</span>
                        </div>
                      ) : (
                        <button 
                          onClick={() => handleBankLogin(bankId)}
                          className="px-3 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                        >
                          Connect
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h3 className="font-medium text-gray-800 mb-2">What happens next?</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start">
                  <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                  <span>You'll be securely redirected to your bank's login page</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                  <span>Enter your credentials directly with your bank (we never see or store them)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                  <span>We'll import your transaction history and account balances</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle size={16} className="text-green-600 mr-2 mt-0.5" />
                  <span>Your personalized financial dashboard will be ready in minutes</span>
                </li>
              </ul>
            </div>
            
            <div className="flex items-center p-4 bg-blue-50 rounded-lg mb-6">
              <Lock size={20} className="text-blue-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-blue-800">Bank-level Security</p>
                <p className="text-xs text-blue-700 mt-1">
                  We use 256-bit encryption and read-only access. Your data is never sold to third parties.
                </p>
              </div>
            </div>
            
            <div className="flex justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-6 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
              >
                Back
              </button>
              
              <button
                onClick={handleConnect}
                disabled={isConnecting || connectedBanks.length === 0}
                className={`px-6 py-2 rounded-lg font-medium ${
                  isConnecting
                    ? 'bg-indigo-400 text-white cursor-not-allowed'
                    : connectedBanks.length === 0
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {isConnecting ? 'Connecting...' : 'Continue to Dashboard'}
              </button>
            </div>
          </div>
        )}
        
        {step === 3 && (
          <div className="text-center py-8">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-green-100 rounded-full">
                <CheckCircle size={32} className="text-green-600" />
              </div>
            </div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">
              {useManualSetup 
                ? "Manual Setup Complete!" 
                : "Accounts Connected Successfully!"}
            </h2>
            <p className="text-gray-600 mb-6">
              {useManualSetup
                ? "We're preparing your dashboard where you can start adding your accounts and transactions."
                : "We're analyzing your financial data to create your personalized dashboard."}
            </p>
            <div className="flex justify-center">
              <div className="animate-pulse">
                <Wallet size={48} className="text-indigo-600" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bank Login Popup */}
      {showLoginPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-lg max-w-md w-full overflow-hidden">
            {connectionSuccess ? (
              // Success state
              <div>
                <div className={`${
                  showLoginPopup.bankId === 'chase' ? 'bg-blue-600' :
                  showLoginPopup.bankId === 'bofa' ? 'bg-red-600' :
                  showLoginPopup.bankId === 'wells' ? 'bg-red-600' : 'bg-indigo-600'
                } p-4 text-white`}>
                  <h3 className="text-lg font-semibold">{showLoginPopup.name}</h3>
                  <p className="text-sm opacity-90">Connection Status</p>
                </div>
                
                <div className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <div className="p-3 bg-green-100 rounded-full">
                      <CheckCircle size={32} className="text-green-600" />
                    </div>
                  </div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-2">Successfully Connected!</h2>
                  <p className="text-gray-600 mb-6">
                    Your {showLoginPopup.name} account has been successfully connected to FinanceAI.
                  </p>
                  
                  <div className="flex justify-center">
                    <button
                      onClick={handleProceed}
                      className={`px-6 py-2 rounded-lg font-medium ${
                        showLoginPopup.bankId === 'chase' ? 'bg-blue-600 hover:bg-blue-700 text-white' :
                        showLoginPopup.bankId === 'bofa' ? 'bg-red-600 hover:bg-red-700 text-white' :
                        showLoginPopup.bankId === 'wells' ? 'bg-red-600 hover:bg-red-700 text-white' : 
                        'bg-indigo-600 hover:bg-indigo-700 text-white'
                      }`}
                    >
                      Proceed
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              // Login form
              <>
                <div className={`${
                  showLoginPopup.bankId === 'chase' ? 'bg-blue-600' :
                  showLoginPopup.bankId === 'bofa' ? 'bg-red-600' :
                  showLoginPopup.bankId === 'wells' ? 'bg-red-600' : 'bg-indigo-600'
                } p-4 text-white`}>
                  <h3 className="text-lg font-semibold">{showLoginPopup.name}</h3>
                  <p className="text-sm opacity-90">Secure Login</p>
                </div>
                
                <div className="p-6">
                  <form onSubmit={handleLoginSubmit}>
                    {/* Chase-specific login form */}
                    {showLoginPopup.bankId === 'chase' && (
                      <>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Username / User ID</label>
                          <input 
                            type="text" 
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Enter username"
                            value={loginUsername}
                            onChange={(e) => setLoginUsername(e.target.value)}
                            disabled={loginLoading}
                          />
                        </div>
                        
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                          <div className="relative">
                            <input 
                              type={showPassword ? "text" : "password"} 
                              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                              placeholder="Enter password"
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                              disabled={loginLoading}
                            />
                            <button 
                              type="button"
                              className="absolute inset-y-0 right-0 pr-3 flex items-center"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? (
                                <EyeOff size={16} className="text-gray-500" />
                              ) : (
                                <Eye size={16} className="text-gray-500" />
                              )}
                            </button>
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <div className="flex items-center">
                            <input 
                              id="remember" 
                              type="checkbox" 
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                            <label htmlFor="remember" className="ml-2 block text-sm text-gray-700">
                              Remember this device
                            </label>
                          </div>
                          <div className="mt-2 flex justify-between">
                            <a href="#" className="text-sm text-blue-600 hover:text-blue-800">Forgot username or password?</a>
                          </div>
                        </div>
                      </>
                    )}
                    
                    {/* Bank of America specific login form */}
                    {showLoginPopup.bankId === 'bofa' && (
                      <>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Online ID</label>
                          <input 
                            type="text" 
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                            placeholder="Enter Online ID"
                            value={loginUsername}
                            onChange={(e) => setLoginUsername(e.target.value)}
                            disabled={loginLoading}
                          />
                        </div>
                        
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Passcode</label>
                          <div className="relative">
                            <input 
                              type={showPassword ? "text" : "password"} 
                              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 pr-10"
                              placeholder="Enter Passcode"
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                              disabled={loginLoading}
                            />
                            <button 
                              type="button"
                              className="absolute inset-y-0 right-0 pr-3 flex items-center"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? (
                                <EyeOff size={16} className="text-gray-500" />
                              ) : (
                                <Eye size={16} className="text-gray-500" />
                              )}
                            </button>
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <div className="flex items-center">
                            <input 
                              id="save-id" 
                              type="checkbox" 
                              className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                            />
                            <label htmlFor="save-id" className="ml-2 block text-sm text-gray-700">
                              Save this Online ID
                            </label>
                          </div>
                          <div className="mt-2 flex justify-between">
                            <a href="#" className="text-sm text-red-600 hover:text-red-800">Forgot ID or Passcode?</a>
                          </div>
                        </div>
                      </>
                    )}
                    
                    {/* Wells Fargo specific login form */}
                    {showLoginPopup.bankId === 'wells' && (
                      <>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                          <input 
                            type="text" 
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                            placeholder="Username"
                            value={loginUsername}
                            onChange={(e) => setLoginUsername(e.target.value)}
                            disabled={loginLoading}
                          />
                        </div>
                        
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                          <div className="relative">
                            <input 
                              type={showPassword ? "text" : "password"} 
                              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 pr-10"
                              placeholder="Password"
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                              disabled={loginLoading}
                            />
                            <button 
                              type="button"
                              className="absolute inset-y-0 right-0 pr-3 flex items-center"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? (
                                <EyeOff size={16} className="text-gray-500" />
                              ) : (
                                <Eye size={16} className="text-gray-500" />
                              )}
                            </button>
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <div className="flex items-center">
                            <input 
                              id="save-username" 
                              type="checkbox" 
                              className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                            />
                            <label htmlFor="save-username" className="ml-2 block text-sm text-gray-700">
                              Save username
                            </label>
                          </div>
                          <div className="mt-2 flex justify-between">
                            <a href="#" className="text-sm text-red-600 hover:text-red-800">Forgot username or password?</a>
                          </div>
                        </div>
                      </>
                    )}
                    
                    {/* Default login form for other banks */}
                    {!['chase', 'bofa', 'wells'].includes(showLoginPopup.bankId) && (
                      <>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                          <input 
                            type="text" 
                            className={`w-full p-2 border rounded-md focus:outline-none focus:ring-2 ${
                              showLoginPopup.bankId === 'chase' ? 'border-gray-300 focus:border-blue-500' :
                              showLoginPopup.bankId === 'bofa' ? 'border-gray-300 focus:border-red-500' :
                              showLoginPopup.bankId === 'wells' ? 'border-gray-300 focus:border-red-500' : 
                              'border-gray-300 focus:border-indigo-500'
                            }`}
                            placeholder="Enter username"
                            value={loginUsername}
                            onChange={(e) => setLoginUsername(e.target.value)}
                            disabled={loginLoading}
                          />
                        </div>
                        
                        <div className="mb-6">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                          <div className="relative">
                            <input 
                              type={showPassword ? "text" : "password"} 
                              className={`w-full p-2 border rounded-md focus:outline-none focus:ring-2 pr-10 ${
                                showLoginPopup.bankId === 'chase' ? 'border-gray-300 focus:border-blue-500' :
                                showLoginPopup.bankId === 'bofa' ? 'border-gray-300 focus:border-red-500' :
                                showLoginPopup.bankId === 'wells' ? 'border-gray-300 focus:border-red-500' : 
                                'border-gray-300 focus:border-indigo-500'
                              }`}
                              placeholder="Enter password"
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                              disabled={loginLoading}
                            />
                            <button 
                              type="button"
                              className="absolute inset-y-0 right-0 pr-3 flex items-center"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? (
                                <EyeOff size={16} className="text-gray-500" />
                              ) : (
                                <Eye size={16} className="text-gray-500" />
                              )}
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                    
                    <div className="flex items-center p-4 bg-blue-50 rounded-lg mb-6">
                      <Shield size={20} className="text-blue-600 mr-3" />
                      <p className="text-sm text-blue-800">
                        Your credentials are securely transmitted directly to your bank.
                      </p>
                    </div>
                    
                    <div className="flex justify-end space-x-3">
                      <button 
                        type="button"
                        onClick={handleClosePopup}
                        className="px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
                        disabled={loginLoading}
                      >
                        Cancel
                      </button>
                      
                      <button 
                        type="submit"
                        disabled={!loginUsername || !loginPassword || loginLoading}
                        className={`px-4 py-2 rounded-lg font-medium flex items-center ${
                          !loginUsername || !loginPassword || loginLoading
                            ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                            : showLoginPopup.bankId === 'chase' ? 'bg-blue-600 hover:bg-blue-700 text-white' :
                              showLoginPopup.bankId === 'bofa' ? 'bg-red-600 hover:bg-red-700 text-white' :
                              showLoginPopup.bankId === 'wells' ? 'bg-red-600 hover:bg-red-700 text-white' : 
                              'bg-indigo-600 hover:bg-indigo-700 text-white'
                        }`}
                      >
                        {loginLoading && <Loader size={16} className="animate-spin mr-2" />}
                        {loginLoading ? 'Connecting...' : 'Connect'}
                      </button>
                    </div>
                  </form>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ConnectAccounts;