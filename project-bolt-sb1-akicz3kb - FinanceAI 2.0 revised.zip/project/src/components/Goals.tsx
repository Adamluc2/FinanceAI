import React, { useState } from 'react';
import { 
  Target, 
  PlusCircle, 
  Home, 
  Plane, 
  GraduationCap, 
  Car, 
  Trash2,
  Edit,
  Calendar,
  DollarSign,
  TrendingUp
} from 'lucide-react';
import CategoryBreakdown from './CategoryBreakdown';
import { useBankData } from './BankDataContext';

const Goals = () => {
  const [showAddGoal, setShowAddGoal] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  
  const { bankData } = useBankData();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  const getGoalIcon = (iconName: string) => {
    switch (iconName) {
      case 'home':
        return <Home size={20} className="text-indigo-600" />;
      case 'plane':
        return <Plane size={20} className="text-blue-600" />;
      case 'car':
        return <Car size={20} className="text-green-600" />;
      case 'piggy-bank':
        return <DollarSign size={20} className="text-purple-600" />;
      case 'education':
        return <GraduationCap size={20} className="text-yellow-600" />;
      default:
        return <Target size={20} className="text-gray-600" />;
    }
  };

  const getTimeRemaining = (targetDate: string) => {
    const target = new Date(targetDate);
    const now = new Date();
    const diffTime = target.getTime() - now.getTime();
    const diffMonths = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 30));
    
    if (diffMonths <= 0) return 'Past due';
    if (diffMonths === 1) return '1 month left';
    return `${diffMonths} months left`;
  };

  const getProgressColor = (progress: number) => {
    if (progress < 25) return 'bg-red-600';
    if (progress < 50) return 'bg-yellow-600';
    if (progress < 75) return 'bg-blue-600';
    return 'bg-green-600';
  };

  if (selectedGoal) {
    return (
      <CategoryBreakdown 
        category={selectedGoal} 
        onBack={() => setSelectedGoal(null)}
        type="goal"
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Financial Goals</h1>
        
        <button 
          onClick={() => setShowAddGoal(true)}
          className="mt-4 md:mt-0 flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
        >
          <PlusCircle size={18} />
          <span>Add New Goal</span>
        </button>
      </div>
      
      {/* Goals Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-indigo-100 rounded-full">
              <Target size={20} className="text-indigo-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">Active Goals</h2>
          </div>
          <p className="text-3xl font-bold text-gray-800">{bankData.goals.length}</p>
          <p className="text-gray-500 mt-1">Goals in progress</p>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-green-100 rounded-full">
              <DollarSign size={20} className="text-green-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">Total Saved</h2>
          </div>
          <p className="text-3xl font-bold text-gray-800">
            {formatCurrency(bankData.goals.reduce((sum, goal) => sum + goal.currentAmount, 0))}
          </p>
          <p className="text-gray-500 mt-1">Across all goals</p>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-blue-100 rounded-full">
              <TrendingUp size={20} className="text-blue-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">Monthly Contribution</h2>
          </div>
          <p className="text-3xl font-bold text-gray-800">
            {formatCurrency(bankData.goals.reduce((sum, goal) => sum + goal.monthlyContribution, 0))}
          </p>
          <p className="text-gray-500 mt-1">Total monthly savings</p>
        </div>
      </div>
      
      {/* Goals List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">Your Financial Goals</h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {bankData.goals.map((goal) => (
            <div 
              key={goal.id} 
              className="p-6 cursor-pointer hover:bg-gray-50"
              onClick={() => setSelectedGoal(goal.name)}
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-gray-100 rounded-full">
                    {getGoalIcon(goal.icon)}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{goal.name}</h3>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <Calendar size={14} className="mr-1" />
                      <span>Target: {formatDate(goal.targetDate)}</span>
                      <span className="mx-2">•</span>
                      <span>{getTimeRemaining(goal.targetDate)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2 mt-4 md:mt-0">
                  <button className="p-2 text-gray-500 hover:text-indigo-600 hover:bg-gray-100 rounded-full">
                    <Edit size={18} />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-red-600 hover:bg-gray-100 rounded-full">
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-500">Current Amount</p>
                  <p className="text-lg font-semibold text-gray-800">{formatCurrency(goal.currentAmount)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Target Amount</p>
                  <p className="text-lg font-semibold text-gray-800">{formatCurrency(goal.targetAmount)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Monthly Contribution</p>
                  <p className="text-lg font-semibold text-gray-800">{formatCurrency(goal.monthlyContribution)}</p>
                </div>
              </div>
              
              <div className="mt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">{goal.progress}% Complete</span>
                  <span className="text-sm text-gray-500">
                    {formatCurrency(goal.targetAmount - goal.currentAmount)} remaining
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className={`${getProgressColor(goal.progress)} h-3 rounded-full`} 
                    style={{ width: `${goal.progress}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="mt-4 p-4 bg-indigo-50 rounded-lg">
                <div className="flex items-start">
                  <div className="p-2 bg-indigo-100 rounded-full mr-3">
                    <Target size={16} className="text-indigo-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">AI Recommendation</p>
                    <p className="text-gray-600 text-sm mt-1">
                      {goal.name === 'Emergency Fund' 
                        ? 'You\'re on track to reach your emergency fund goal. Consider increasing your monthly contribution by $100 to reach your goal 1 month earlier.'
                        : goal.name === 'Vacation to Japan'
                        ? 'Based on your spending patterns, you could increase your monthly contribution by $150 by reducing dining out expenses.'
                        : goal.name === 'Home Down Payment'
                        ? 'You\'re making good progress. Consider setting up automatic transfers to ensure consistent contributions.'
                        : 'Try reducing your entertainment expenses to increase your monthly contribution and reach your goal faster.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Add Goal Modal (simplified) */}
      {showAddGoal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Add New Financial Goal</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Goal Name</label>
                <input 
                  type="text" 
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g., New Car, Vacation, etc."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Amount</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500">$</span>
                  </div>
                  <input 
                    type="number" 
                    className="w-full pl-8 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="0"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Date</label>
                <input 
                  type="date" 
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Contribution</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500">$</span>
                  </div>
                  <input 
                    type="number" 
                    className="w-full pl-8 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="0"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option>Savings</option>
                  <option>Housing</option>
                  <option>Transportation</option>
                  <option>Travel</option>
                  <option>Education</option>
                  <option>Other</option>
                </select>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <button 
                onClick={() => setShowAddGoal(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                onClick={() => setShowAddGoal(false)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Create Goal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Goals;