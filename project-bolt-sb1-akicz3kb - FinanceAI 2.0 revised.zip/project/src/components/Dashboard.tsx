import React, { useState } from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  DollarSign, 
  TrendingUp, 
  AlertCircle,
  PiggyBank,
  CreditCard,
  Target,
  Plus
} from 'lucide-react';
import CategoryBreakdown from './CategoryBreakdown';
import { useBankData } from './BankDataContext';
import AddAccountModal from './modals/AddAccountModal';
import AddTransactionModal from './modals/AddTransactionModal';

const Dashboard = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { bankData, isManualSetup } = useBankData();
  const [showAddAccountModal, setShowAddAccountModal] = useState(false);
  const [showAddTransactionModal, setShowAddTransactionModal] = useState(false);

  // Format currency helper
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (selectedCategory) {
    return (
      <CategoryBreakdown 
        category={selectedCategory} 
        onBack={() => setSelectedCategory(null)}
        type="spending"
      />
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Financial Dashboard</h1>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Net Worth</p>
              <p className="text-2xl font-bold text-gray-800">{formatCurrency(bankData.netWorth)}</p>
            </div>
            <div className="p-2 bg-green-100 rounded-full">
              <TrendingUp className="text-green-600" size={20} />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpRight className="text-green-500 mr-1" size={16} />
            <span className="text-green-500 font-medium">+8.2%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Monthly Income</p>
              <p className="text-2xl font-bold text-gray-800">{formatCurrency(bankData.monthlyIncome)}</p>
            </div>
            <div className="p-2 bg-blue-100 rounded-full">
              <DollarSign className="text-blue-600" size={20} />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpRight className="text-green-500 mr-1" size={16} />
            <span className="text-green-500 font-medium">+2.5%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Monthly Expenses</p>
              <p className="text-2xl font-bold text-gray-800">{formatCurrency(bankData.monthlyExpenses)}</p>
            </div>
            <div className="p-2 bg-red-100 rounded-full">
              <CreditCard className="text-red-600" size={20} />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowDownRight className="text-red-500 mr-1" size={16} />
            <span className="text-red-500 font-medium">+4.3%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Savings Rate</p>
              <p className="text-2xl font-bold text-gray-800">{bankData.savingsRate}%</p>
            </div>
            <div className="p-2 bg-purple-100 rounded-full">
              <PiggyBank className="text-purple-600" size={20} />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <ArrowUpRight className="text-green-500 mr-1" size={16} />
            <span className="text-green-500 font-medium">+1.8%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
      </div>
      
      {/* Accounts Overview */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Accounts Overview</h2>
          <button 
            onClick={() => setShowAddAccountModal(true)}
            className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-800"
          >
            <Plus size={16} />
            <span>{isManualSetup ? "Add Account" : "Connect Account"}</span>
          </button>
        </div>
        <div className="divide-y divide-gray-200">
          {bankData.accounts.length > 0 ? (
            bankData.accounts.map((account, index) => (
              <div 
                key={index} 
                className="p-6 flex justify-between items-center hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedCategory(account.name)}
              >
                <div className="flex items-center">
                  <div className={`p-2 rounded-full mr-4 ${
                    account.type === 'checking' || account.type === 'savings' ? 'bg-blue-100' : 
                    account.type === 'investment' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {account.type === 'checking' || account.type === 'savings' ? <DollarSign size={20} className="text-blue-600" /> : 
                     account.type === 'investment' ? <TrendingUp size={20} className="text-green-600" /> : 
                     <CreditCard size={20} className="text-red-600" />}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">{account.name}</p>
                    <p className="text-sm text-gray-500">{account.institution}</p>
                  </div>
                </div>
                <p className={`font-semibold ${account.balance < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                  {formatCurrency(account.balance)}
                </p>
              </div>
            ))
          ) : (
            <div className="p-8 text-center">
              <p className="text-gray-500 mb-4">No accounts added yet.</p>
              <button 
                onClick={() => setShowAddAccountModal(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                {isManualSetup ? "Add Your First Account" : "Connect Your First Account"}
              </button>
            </div>
          )}
        </div>
        {bankData.accounts.length > 0 && (
          <div className="p-4 bg-gray-50 rounded-b-lg">
            <button 
              onClick={() => setShowAddAccountModal(true)}
              className="text-indigo-600 font-medium text-sm hover:text-indigo-800"
            >
              + {isManualSetup ? "Add another account" : "Connect another account"}
            </button>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Bills */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Upcoming Bills</h2>
            <button 
              onClick={() => setShowAddTransactionModal(true)}
              className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-800"
            >
              <Plus size={16} />
              <span>Add Bill</span>
            </button>
          </div>
          <div className="divide-y divide-gray-200">
            {bankData.upcomingBills.length > 0 ? (
              bankData.upcomingBills.map((bill, index) => (
                <div 
                  key={index} 
                  className="p-4 flex justify-between items-center hover:bg-gray-50 cursor-pointer"
                  onClick={() => setSelectedCategory(bill.name)}
                >
                  <div>
                    <p className="font-medium text-gray-800">{bill.name}</p>
                    <p className="text-sm text-gray-500">Due {new Date(bill.dueDate).toLocaleDateString()}</p>
                  </div>
                  <p className="font-semibold text-gray-800">{formatCurrency(bill.amount)}</p>
                </div>
              ))
            ) : (
              <div className="p-8 text-center">
                <p className="text-gray-500">No upcoming bills.</p>
              </div>
            )}
          </div>
          <div className="p-4 bg-gray-50 rounded-b-lg">
            <button 
              onClick={() => setShowAddTransactionModal(true)}
              className="text-indigo-600 font-medium text-sm hover:text-indigo-800"
            >
              + Add bill
            </button>
          </div>
        </div>
        
        {/* Financial Goals */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Financial Goals</h2>
            <button 
              onClick={() => setSelectedCategory('Add Goal')}
              className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-800"
            >
              <Plus size={16} />
              <span>Add Goal</span>
            </button>
          </div>
          <div className="divide-y divide-gray-200">
            {bankData.goals.length > 0 ? (
              bankData.goals.map((goal, index) => (
                <div 
                  key={index} 
                  className="p-4 hover:bg-gray-50 cursor-pointer"
                  onClick={() => setSelectedCategory(goal.name)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <p className="font-medium text-gray-800">{goal.name}</p>
                      <p className="text-sm text-gray-500">
                        {formatCurrency(goal.currentAmount)} of {formatCurrency(goal.targetAmount)}
                      </p>
                    </div>
                    <div className="flex items-center">
                      <Target size={16} className="text-indigo-600 mr-1" />
                      <span className="text-indigo-600 font-medium">{goal.progress}%</span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-indigo-600 h-2 rounded-full" 
                      style={{ width: `${goal.progress}%` }}
                    ></div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center">
                <p className="text-gray-500">No financial goals set yet.</p>
              </div>
            )}
          </div>
          <div className="p-4 bg-gray-50 rounded-b-lg">
            <button 
              onClick={() => setSelectedCategory('Add Goal')}
              className="text-indigo-600 font-medium text-sm hover:text-indigo-800"
            >
              + Add new goal
            </button>
          </div>
        </div>
      </div>
      
      {/* AI Insights */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">AI Insights</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {bankData.insights.length > 0 ? (
            bankData.insights.map((insight, index) => (
              <div 
                key={index} 
                className="p-4 flex items-start hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedCategory(insight.type === 'warning' ? 'Dining' : 
                                                  insight.type === 'opportunity' ? 'Internet' : 'Emergency Fund')}
              >
                <div className={`p-2 rounded-full mr-3 ${
                  insight.type === 'warning' ? 'bg-yellow-100' : 
                  insight.type === 'opportunity' ? 'bg-blue-100' : 'bg-green-100'
                }`}>
                  {insight.type === 'warning' && <AlertCircle size={18} className="text-yellow-600" />}
                  {insight.type === 'opportunity' && <DollarSign size={18} className="text-blue-600" />}
                  {insight.type === 'positive' && <TrendingUp size={18} className="text-green-600" />}
                </div>
                <p className="text-gray-700">{insight.text}</p>
              </div>
            ))
          ) : (
            <div className="p-8 text-center">
              <p className="text-gray-500">No insights available yet. Add more financial data to get personalized insights.</p>
            </div>
          )}
        </div>
        {bankData.insights.length > 0 && (
          <div className="p-4 bg-gray-50 rounded-b-lg">
            <button className="text-indigo-600 font-medium text-sm hover:text-indigo-800">
              View all insights
            </button>
          </div>
        )}
      </div>

      {/* Add Account Modal */}
      {showAddAccountModal && (
        <AddAccountModal onClose={() => setShowAddAccountModal(false)} />
      )}

      {/* Add Transaction Modal */}
      {showAddTransactionModal && (
        <AddTransactionModal onClose={() => setShowAddTransactionModal(false)} />
      )}
    </div>
  );
};

export default Dashboard;