import React, { useState } from 'react';
import { 
  User, 
  Mail, 
  Lock, 
  Bell, 
  Shield, 
  CreditCard, 
  X,
  Check,
  ChevronRight,
  LogOut,
  Smartphone,
  Eye,
  EyeOff,
  Plus,
  Edit,
  Palette,
  Moon,
  Sun
} from 'lucide-react';
import { useTheme } from '../ThemeContext';

interface UserSettingsProps {
  onClose: () => void;
  onLogout: () => void;
}

const UserSettings: React.FC<UserSettingsProps> = ({ onClose, onLogout }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [showPassword, setShowPassword] = useState(false);
  const { theme, setTheme } = useTheme();
  
  // Mock user data
  const user = {
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    avatar: null,
    twoFactorEnabled: true,
    emailNotifications: {
      transactions: true,
      budgetAlerts: true,
      goalProgress: true,
      billReminders: true,
      insights: false,
      marketing: false
    },
    pushNotifications: {
      transactions: true,
      budgetAlerts: true,
      goalProgress: false,
      billReminders: true,
      insights: true,
      marketing: false
    },
    connectedAccounts: [
      { name: 'Chase Bank', connected: true, lastSync: '2025-04-22T14:30:00Z' },
      { name: 'American Express', connected: true, lastSync: '2025-04-22T14:30:00Z' }
    ]
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'accounts', label: 'Connected Accounts', icon: CreditCard },
    { id: 'appearance', label: 'Appearance', icon: Palette },
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-gray-50 border-r border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-800">Settings</h2>
              <button 
                onClick={onClose}
                className="p-1 rounded-full hover:bg-gray-200 md:hidden"
              >
                <X size={20} className="text-gray-600" />
              </button>
            </div>
          </div>
          
          <nav className="p-4">
            <ul className="space-y-1">
              {tabs.map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-3 rounded-lg ${
                        activeTab === tab.id
                          ? 'bg-indigo-50 text-indigo-700'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <IconComponent size={18} className="mr-3" />
                      <span>{tab.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
            
            <div className="mt-6 pt-6 border-t border-gray-200">
              <button 
                onClick={onLogout}
                className="w-full flex items-center px-4 py-3 rounded-lg text-red-600 hover:bg-red-50"
              >
                <LogOut size={18} className="mr-3" />
                <span>Logout</span>
              </button>
            </div>
          </nav>
        </div>
        
        {/* Content */}
        <div className="flex-1 p-6">
          <div className="hidden md:flex justify-end mb-6">
            <button 
              onClick={onClose}
              className="p-2 rounded-full hover:bg-gray-100"
            >
              <X size={20} className="text-gray-600" />
            </button>
          </div>
          
          {/* Profile Settings */}
          {activeTab === 'profile' && (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-6">Profile Settings</h3>
              
              <div className="mb-8">
                <div className="flex items-center mb-6">
                  <div className="h-20 w-20 rounded-full bg-indigo-100 flex items-center justify-center text-2xl font-semibold text-indigo-600 mr-6">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                      Upload Photo
                    </button>
                    <p className="text-sm text-gray-500 mt-1">JPG, GIF or PNG. 1MB max.</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <input 
                    type="text" 
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    defaultValue={user.name}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <input 
                    type="email" 
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    defaultValue={user.email}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                  <input 
                    type="tel" 
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    defaultValue={user.phone}
                  />
                </div>
                
                <div className="pt-4">
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Security Settings */}
          {activeTab === 'security' && (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-6">Security Settings</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">Change Password</h4>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                      <div className="relative">
                        <input 
                          type={showPassword ? "text" : "password"} 
                          className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-10"
                          placeholder="••••••••"
                        />
                        <button 
                          className="absolute inset-y-0 right-0 pr-3 flex items-center"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <EyeOff size={18} className="text-gray-500" />
                          ) : (
                            <Eye size={18} className="text-gray-500" />
                          )}
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                      <input 
                        type="password" 
                        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="••••••••"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                      <input 
                        type="password" 
                        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="••••••••"
                      />
                    </div>
                    
                    <div className="pt-2">
                      <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                        Update Password
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-800 mb-4">Two-Factor Authentication</h4>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="p-2 bg-indigo-100 rounded-full mr-4">
                        <Smartphone size={20} className="text-indigo-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">Two-factor authentication</p>
                        <p className="text-sm text-gray-500">
                          {user.twoFactorEnabled 
                            ? 'Enabled - Using Authenticator App' 
                            : 'Disabled - Your account is less secure'}
                        </p>
                      </div>
                    </div>
                    
                    <button className={`px-4 py-2 rounded-lg ${
                      user.twoFactorEnabled 
                        ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                        : 'bg-green-100 text-green-700 hover:bg-green-200'
                    }`}>
                      {user.twoFactorEnabled ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                </div>
                
                <div className="pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-800 mb-4">Sessions</h4>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-800">Current Session</p>
                        <p className="text-sm text-gray-500">Web Browser - Last active now</p>
                      </div>
                      
                      <div className="flex items-center text-green-600">
                        <Check size={16} className="mr-1" />
                        <span className="text-sm font-medium">Active</span>
                      </div>
                    </div>
                  </div>
                  
                  <button className="mt-4 text-red-600 font-medium text-sm hover:text-red-800">
                    Log out of all other sessions
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Notification Settings */}
          {activeTab === 'notifications' && (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-6">Notification Settings</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">Email Notifications</h4>
                  
                  <div className="space-y-3">
                    {Object.entries(user.emailNotifications).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-800">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</p>
                          <p className="text-sm text-gray-500">
                            {key === 'transactions' && 'Receive emails for new transactions'}
                            {key === 'budgetAlerts' && 'Get notified when you approach budget limits'}
                            {key === 'goalProgress' && 'Updates on your financial goal progress'}
                            {key === 'billReminders' && 'Reminders about upcoming bill payments'}
                            {key === 'insights' && 'Personalized financial insights and tips'}
                            {key === 'marketing' && 'News, updates, and promotional offers'}
                          </p>
                        </div>
                        
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked={value} />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-800 mb-4">Push Notifications</h4>
                  
                  <div className="space-y-3">
                    {Object.entries(user.pushNotifications).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-800">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</p>
                          <p className="text-sm text-gray-500">
                            {key === 'transactions' && 'Receive alerts for new transactions'}
                            {key === 'budgetAlerts' && 'Get notified when you approach budget limits'}
                            {key === 'goalProgress' && 'Updates on your financial goal progress'}
                            {key === 'billReminders' && 'Reminders about upcoming bill payments'}
                            {key === 'insights' && 'Personalized financial insights and tips'}
                            {key === 'marketing' && 'News, updates, and promotional offers'}
                          </p>
                        </div>
                        
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked={value} />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4">
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    Save Preferences
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Appearance Settings */}
          {activeTab === 'appearance' && (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-6">Appearance Settings</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">Theme</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button
                      onClick={() => setTheme('light')}
                      className={`p-4 border rounded-lg flex items-center ${
                        theme === 'light' 
                          ? 'border-indigo-600 bg-indigo-50' 
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      <div className="p-3 bg-yellow-100 rounded-full mr-4">
                        <Sun size={24} className="text-yellow-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-800">Light Mode</p>
                        <p className="text-sm text-gray-500">Light background with dark text</p>
                      </div>
                      {theme === 'light' && (
                        <div className="ml-2">
                          <Check size={20} className="text-indigo-600" />
                        </div>
                      )}
                    </button>
                    
                    <button
                      onClick={() => setTheme('dark')}
                      className={`p-4 border rounded-lg flex items-center ${
                        theme === 'dark' 
                          ? 'border-indigo-600 bg-indigo-50' 
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      <div className="p-3 bg-indigo-100 rounded-full mr-4">
                        <Moon size={24} className="text-indigo-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-800">Dark Mode</p>
                        <p className="text-sm text-gray-500">Dark background with light text</p>
                      </div>
                      {theme === 'dark' && (
                        <div className="ml-2">
                          <Check size={20} className="text-indigo-600" />
                        </div>
                      )}
                    </button>
                  </div>
                </div>
                
                <div className="pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-800 mb-4">Display Preferences</h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-800">Compact View</p>
                        <p className="text-sm text-gray-500">
                          Show more information with less spacing
                        </p>
                      </div>
                      
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </label>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-800">Animations</p>
                        <p className="text-sm text-gray-500">
                          Enable animations throughout the interface
                        </p>
                      </div>
                      
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked={true} />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    Save Preferences
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Connected Accounts */}
          {activeTab === 'accounts' && (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-6">Connected Accounts</h3>
              
              <div className="space-y-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-gray-600">
                    Manage your connected financial accounts. Disconnecting an account will remove its data from your dashboard.
                  </p>
                </div>
                
                <div className="space-y-4">
                  {user.connectedAccounts.map((account, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="p-2 bg-blue-100 rounded-full mr-4">
                            <CreditCard size={20} className="text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{account.name}</p>
                            <p className="text-sm text-gray-500">
                              {account.connected 
                                ? `Last synced: ${formatDate(account.lastSync)}` 
                                : 'Not connected'}
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          {account.connected ? (
                            <button className="px-3 py-1 border border-red-300 text-red-600 rounded-lg hover:bg-red-50">
                              Disconnect
                            </button>
                          ) : (
                            <button className="px-3 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                              Connect
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <button className="flex items-center text-indigo-600 font-medium hover:text-indigo-800">
                  <Plus size={16} className="mr-1" />
                  Connect Another Account
                </button>
                
                <div className="pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-800 mb-4">Data Management</h4>
                  
                  <div className="space-y-4">
                    <button className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <span className="font-medium text-gray-800">Export Financial Data</span>
                      <ChevronRight size={18} className="text-gray-500" />
                    </button>
                    
                    <button className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <span className="font-medium text-gray-800">Sync Frequency Settings</span>
                      <ChevronRight size={18} className="text-gray-500" />
                    </button>
                    
                    <button className="w-full flex items-center justify-between p-4 border border-red-200 text-red-600 rounded-lg hover:bg-red-50">
                      <span className="font-medium">Delete All Financial Data</span>
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserSettings;