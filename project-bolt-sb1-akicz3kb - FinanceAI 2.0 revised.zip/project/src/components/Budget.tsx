import React, { useState } from 'react';
import { 
  PieChart, 
  BarChart3, 
  ShoppingBag, 
  Coffee, 
  Home, 
  Car, 
  Utensils, 
  Wifi, 
  ShoppingCart,
  DollarSign,
  Plane,
  Heart,
  Edit,
  Plus
} from 'lucide-react';
import CategoryBreakdown from './CategoryBreakdown';
import { useBankData } from './BankDataContext';
import AddBudgetModal from './modals/AddBudgetModal';

const Budget = () => {
  const [selectedMonth, setSelectedMonth] = useState('April 2025');
  const [selectedView, setSelectedView] = useState('categories');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAddBudget, setShowAddBudget] = useState(false);
  
  const { bankData } = useBankData();

  // Calculate total budget and spent
  const totalBudget = bankData.budgets.reduce((sum, budget) => sum + budget.budgeted, 0);
  const totalSpent = bankData.budgets.reduce((sum, budget) => sum + budget.spent, 0);
  const totalBudgetPercentage = Math.round((totalSpent / totalBudget) * 100) || 0;

  const months = [
    'January 2025',
    'February 2025',
    'March 2025',
    'April 2025',
    'May 2025',
  ];

  const views = [
    { id: 'categories', label: 'Categories', icon: PieChart },
    { id: 'trends', label: 'Trends', icon: BarChart3 },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getCategoryIcon = (category: any) => {
    const IconComponent = getIconComponent(category.icon);
    return (
      <div className={`p-2 rounded-full bg-${category.color}-100`}>
        <IconComponent size={18} className={`text-${category.color}-600`} />
      </div>
    );
  };
  
  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'ShoppingBag': return ShoppingBag;
      case 'Coffee': return Coffee;
      case 'Home': return Home;
      case 'Car': return Car;
      case 'Utensils': return Utensils;
      case 'Wifi': return Wifi;
      case 'ShoppingCart': return ShoppingCart;
      case 'Plane': return Plane;
      case 'Heart': return Heart;
      default: return DollarSign;
    }
  };

  const getStatusColor = (percentage: number) => {
    if (percentage > 100) return 'text-red-600';
    if (percentage > 90) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getProgressColor = (percentage: number) => {
    if (percentage > 100) return 'bg-red-600';
    if (percentage > 90) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  if (selectedCategory) {
    return (
      <CategoryBreakdown 
        category={selectedCategory} 
        onBack={() => setSelectedCategory(null)}
        type="budget"
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Budget</h1>
        
        <div className="flex items-center space-x-4 mt-4 md:mt-0">
          <select
            className="border border-gray-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
          >
            {months.map((month) => (
              <option key={month} value={month}>
                {month}
              </option>
            ))}
          </select>
          
          <div className="flex p-1 bg-gray-100 rounded-lg">
            {views.map((view) => {
              const IconComponent = view.icon;
              return (
                <button
                  key={view.id}
                  onClick={() => setSelectedView(view.id)}
                  className={`flex items-center space-x-1 px-3 py-1 rounded-md ${
                    selectedView === view.id
                      ? 'bg-white shadow-sm'
                      : 'hover:bg-gray-200'
                  }`}
                >
                  <IconComponent size={16} />
                  <span>{view.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Budget Overview */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h2 className="text-lg font-semibold text-gray-800">Budget Overview</h2>
            <p className="text-gray-500">
              {formatCurrency(totalSpent)} spent of {formatCurrency(totalBudget)} budgeted
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <button 
              onClick={() => setShowAddBudget(true)}
              className="flex items-center space-x-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              <Edit size={16} />
              <span>Edit Budget</span>
            </button>
          </div>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
          <div 
            className={`${getProgressColor(totalBudgetPercentage)} h-4 rounded-full`} 
            style={{ width: `${Math.min(totalBudgetPercentage, 100)}%` }}
          ></div>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className={getStatusColor(totalBudgetPercentage)}>
            {totalBudgetPercentage}% used
          </span>
          <span className="text-gray-500">
            {formatCurrency(totalBudget - totalSpent)} remaining
          </span>
        </div>
      </div>
      
      {/* Category Breakdown */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Category Breakdown</h2>
          <button 
            onClick={() => setShowAddBudget(true)}
            className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-800"
          >
            <Plus size={16} />
            <span>Add Category</span>
          </button>
        </div>
        
        <div className="divide-y divide-gray-200">
          {bankData.budgets.length > 0 ? (
            bankData.budgets.map((category, index) => (
              <div 
                key={index} 
                className="p-4 hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedCategory(category.category)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    {getCategoryIcon(category)}
                    <div>
                      <p className="font-medium text-gray-800">{category.category}</p>
                      <p className="text-sm text-gray-500">
                        {formatCurrency(category.spent)} of {formatCurrency(category.budgeted)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${getStatusColor(category.percentage)}`}>
                      {category.percentage}%
                    </p>
                    <p className="text-sm text-gray-500">
                      {formatCurrency(category.budgeted - category.spent)} left
                    </p>
                  </div>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`${getProgressColor(category.percentage)} h-2 rounded-full`} 
                    style={{ width: `${Math.min(category.percentage, 100)}%` }}
                  ></div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center">
              <p className="text-gray-500 mb-4">No budget categories set up yet.</p>
              <button 
                onClick={() => setShowAddBudget(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Create Your First Budget
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* AI Budget Recommendations */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">AI Budget Recommendations</h2>
        
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-start">
              <div className="p-2 bg-blue-100 rounded-full mr-3">
                <DollarSign size={18} className="text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-800">Optimize your Entertainment budget</p>
                <p className="text-gray-600 mt-1">
                  You're consistently overspending in Entertainment. Consider increasing your budget by $30 or finding ways to reduce costs.
                </p>
                <button className="mt-2 text-blue-600 font-medium text-sm hover:text-blue-800">
                  Apply recommendation
                </button>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-start">
              <div className="p-2 bg-green-100 rounded-full mr-3">
                <DollarSign size={18} className="text-green-600" />
              </div>
              <div>
                <p className="font-medium text-gray-800">Healthcare savings opportunity</p>
                <p className="text-gray-600 mt-1">
                  You're consistently under budget in Healthcare. Consider reallocating $30 to your Shopping category where you tend to overspend.
                </p>
                <button className="mt-2 text-green-600 font-medium text-sm hover:text-green-800">
                  Apply recommendation
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Budget Modal */}
      {showAddBudget && (
        <AddBudgetModal onClose={() => setShowAddBudget(false)} />
      )}
    </div>
  );
};

export default Budget;