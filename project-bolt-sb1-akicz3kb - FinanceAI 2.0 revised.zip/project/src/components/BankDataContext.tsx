import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define types for our financial data
interface Account {
  id: string;
  name: string;
  type: 'checking' | 'savings' | 'credit' | 'investment';
  balance: number;
  institution: string;
  lastUpdated: string;
}

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  category: string;
  account: string;
  pending: boolean;
}

interface Budget {
  category: string;
  budgeted: number;
  spent: number;
  percentage: number;
  icon: string;
  color: string;
}

interface Goal {
  id: number;
  name: string;
  icon: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  category: string;
  priority: string;
  monthlyContribution: number;
  progress: number;
}

interface Investment {
  name: string;
  ticker: string;
  shares: number;
  price: number;
  value: number;
  change: number;
  allocation: number;
}

interface AssetAllocation {
  category: string;
  percentage: number;
  value: number;
}

interface Bill {
  name: string;
  amount: number;
  dueDate: string;
  status: string;
}

interface Insight {
  id: number;
  text: string;
  type: string;
}

interface BankData {
  accounts: Account[];
  transactions: Transaction[];
  budgets: Budget[];
  goals: Goal[];
  investments: Investment[];
  assetAllocations: AssetAllocation[];
  netWorth: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlySavings: number;
  savingsRate: number;
  upcomingBills: Bill[];
  insights: Insight[];
  isLoaded: boolean;
  connectedBanks: string[];
}

interface BankDataContextType {
  bankData: BankData;
  isLoading: boolean;
  isManualSetup: boolean;
  connectBank: (bankId: string) => void;
  disconnectBank: (bankId: string) => void;
  refreshData: () => void;
  addAccount: (account: Account) => void;
  updateAccount: (accountId: string, updates: Partial<Account>) => void;
  deleteAccount: (accountId: string) => void;
  addTransaction: (transaction: Transaction) => void;
  updateTransaction: (transactionId: string, updates: Partial<Transaction>) => void;
  deleteTransaction: (transactionId: string) => void;
  addBudget: (budget: Budget) => void;
  updateBudget: (category: string, updates: Partial<Budget>) => void;
  deleteBudget: (category: string) => void;
  addGoal: (goal: Goal) => void;
  updateGoal: (goalId: number, updates: Partial<Goal>) => void;
  deleteGoal: (goalId: number) => void;
  addInvestment: (investment: Investment) => void;
  addBill: (bill: Bill) => void;
  setManualSetup: (isManual: boolean) => void;
}

// Default data (used before any banks are connected)
const defaultData: BankData = {
  accounts: [],
  transactions: [],
  budgets: [],
  goals: [],
  investments: [],
  assetAllocations: [],
  netWorth: 0,
  monthlyIncome: 0,
  monthlyExpenses: 0,
  monthlySavings: 0,
  savingsRate: 0,
  upcomingBills: [],
  insights: [],
  isLoaded: false,
  connectedBanks: []
};

// Mock data for Chase Bank
const chaseData = {
  accounts: [
    { 
      id: 'chase-checking', 
      name: 'Chase Checking', 
      type: 'checking' as const, 
      balance: 3450, 
      institution: 'Chase Bank',
      lastUpdated: new Date().toISOString()
    },
    { 
      id: 'chase-savings', 
      name: 'Chase Savings', 
      type: 'savings' as const, 
      balance: 12500, 
      institution: 'Chase Bank',
      lastUpdated: new Date().toISOString()
    }
  ],
  transactions: [
    { 
      id: 'tx1', 
      date: '2025-04-22', 
      description: 'Whole Foods Market', 
      amount: -128.45, 
      category: 'Groceries', 
      account: 'Chase Checking',
      pending: false
    },
    { 
      id: 'tx3', 
      date: '2025-04-20', 
      description: 'Netflix', 
      amount: -14.99, 
      category: 'Entertainment', 
      account: 'Chase Checking',
      pending: false
    },
    { 
      id: 'tx6', 
      date: '2025-04-18', 
      description: 'Rent Payment', 
      amount: -1800.00, 
      category: 'Housing', 
      account: 'Chase Checking',
      pending: false
    },
    { 
      id: 'tx7', 
      date: '2025-04-15', 
      description: 'Salary Deposit', 
      amount: 2600.00, 
      category: 'Income', 
      account: 'Chase Checking',
      pending: false
    },
    { 
      id: 'tx8', 
      date: '2025-04-15', 
      description: 'Electric Bill', 
      amount: -95.40, 
      category: 'Utilities', 
      account: 'Chase Checking',
      pending: false
    }
  ],
  budgets: [
    { 
      category: 'Housing', 
      budgeted: 1800, 
      spent: 1800, 
      percentage: 100,
      icon: 'Home',
      color: 'indigo'
    },
    { 
      category: 'Utilities', 
      budgeted: 250, 
      spent: 245, 
      percentage: 98,
      icon: 'Wifi',
      color: 'yellow'
    },
    { 
      category: 'Entertainment', 
      budgeted: 100, 
      spent: 85, 
      percentage: 85,
      icon: 'Coffee',
      color: 'purple'
    },
    { 
      category: 'Groceries', 
      budgeted: 400, 
      spent: 350, 
      percentage: 88,
      icon: 'ShoppingCart',
      color: 'green'
    }
  ],
  upcomingBills: [
    { name: 'Rent', amount: 1800, dueDate: '2025-05-01', status: 'upcoming' },
    { name: 'Electricity', amount: 95, dueDate: '2025-04-28', status: 'upcoming' },
    { name: 'Internet', amount: 75, dueDate: '2025-04-30', status: 'upcoming' }
  ],
  goals: [
    {
      id: 1,
      name: 'Emergency Fund',
      icon: 'piggy-bank',
      targetAmount: 15000,
      currentAmount: 12500,
      targetDate: '2025-08-01',
      category: 'Savings',
      priority: 'High',
      monthlyContribution: 500,
      progress: 83,
    }
  ]
};

// Mock data for Amex
const amexData = {
  accounts: [
    { 
      id: 'amex-credit', 
      name: 'Amex Credit Card', 
      type: 'credit' as const, 
      balance: -1770, 
      institution: 'American Express',
      lastUpdated: new Date().toISOString()
    }
  ],
  transactions: [
    { 
      id: 'tx2', 
      date: '2025-04-21', 
      description: 'Starbucks', 
      amount: -5.65, 
      category: 'Dining', 
      account: 'Amex Credit Card',
      pending: false
    },
    { 
      id: 'tx4', 
      date: '2025-04-20', 
      description: 'Uber', 
      amount: -24.50, 
      category: 'Transportation', 
      account: 'Amex Credit Card',
      pending: false
    },
    { 
      id: 'tx5', 
      date: '2025-04-19', 
      description: 'Amazon', 
      amount: -67.32, 
      category: 'Shopping', 
      account: 'Amex Credit Card',
      pending: false
    },
    { 
      id: 'tx9', 
      date: '2025-04-14', 
      description: 'Target', 
      amount: -42.67, 
      category: 'Shopping', 
      account: 'Amex Credit Card',
      pending: false
    },
    { 
      id: 'tx10', 
      date: '2025-04-12', 
      description: 'Chipotle', 
      amount: -12.85, 
      category: 'Dining', 
      account: 'Amex Credit Card',
      pending: false
    }
  ],
  budgets: [
    { 
      category: 'Food', 
      budgeted: 600, 
      spent: 580, 
      percentage: 97,
      icon: 'Utensils',
      color: 'orange'
    },
    { 
      category: 'Transportation', 
      budgeted: 300, 
      spent: 285, 
      percentage: 95,
      icon: 'Car',
      color: 'blue'
    },
    { 
      category: 'Shopping', 
      budgeted: 300, 
      spent: 350, 
      percentage: 117,
      icon: 'ShoppingBag',
      color: 'pink'
    }
  ],
  upcomingBills: [
    { name: 'Car Insurance', amount: 120, dueDate: '2025-05-05', status: 'upcoming' }
  ],
  goals: [
    {
      id: 2,
      name: 'Vacation to Japan',
      icon: 'plane',
      targetAmount: 5000,
      currentAmount: 2800,
      targetDate: '2025-12-15',
      category: 'Travel',
      priority: 'Medium',
      monthlyContribution: 300,
      progress: 56,
    }
  ]
};

// Mock data for Vanguard
const vanguardData = {
  accounts: [
    { 
      id: 'vanguard-investment', 
      name: 'Investment Portfolio', 
      type: 'investment' as const, 
      balance: 28500, 
      institution: 'Vanguard',
      lastUpdated: new Date().toISOString()
    }
  ],
  investments: [
    { 
      name: 'S&P 500 ETF', 
      ticker: 'VOO', 
      shares: 15, 
      price: 450.25, 
      value: 6753.75, 
      change: 2.3,
      allocation: 23.7
    },
    { 
      name: 'Total Bond Market ETF', 
      ticker: 'BND', 
      shares: 60, 
      price: 72.35, 
      value: 4341, 
      change: -0.5,
      allocation: 15.2
    },
    { 
      name: 'Technology Sector ETF', 
      ticker: 'VGT', 
      shares: 8, 
      price: 520.80, 
      value: 4166.4, 
      change: 3.1,
      allocation: 14.6
    },
    { 
      name: 'Dividend Appreciation ETF', 
      ticker: 'VIG', 
      shares: 25, 
      price: 180.45, 
      value: 4511.25, 
      change: 1.2,
      allocation: 15.8
    },
    { 
      name: 'International Stock ETF', 
      ticker: 'VXUS', 
      shares: 40, 
      price: 58.75, 
      value: 2350, 
      change: -1.8,
      allocation: 8.2
    }
  ],
  assetAllocations: [
    { category: 'Stocks', percentage: 65, value: 18525 },
    { category: 'Bonds', percentage: 20, value: 5700 },
    { category: 'Cash', percentage: 10, value: 2850 },
    { category: 'Alternative', percentage: 5, value: 1425 }
  ],
  goals: [
    {
      id: 3,
      name: 'Home Down Payment',
      icon: 'home',
      targetAmount: 60000,
      currentAmount: 28500,
      targetDate: '2026-06-30',
      category: 'Housing',
      priority: 'High',
      monthlyContribution: 1200,
      progress: 48,
    },
    {
      id: 4,
      name: 'New Car',
      icon: 'car',
      targetAmount: 25000,
      currentAmount: 5200,
      targetDate: '2026-03-15',
      category: 'Transportation',
      priority: 'Medium',
      monthlyContribution: 800,
      progress: 21,
    }
  ]
};

// Create the context
const BankDataContext = createContext<BankDataContextType | undefined>(undefined);

// Provider component
export const BankDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bankData, setBankData] = useState<BankData>(defaultData);
  const [isLoading, setIsLoading] = useState(false);
  const [isManualSetup, setIsManualSetup] = useState(false);

  // Function to merge data from multiple banks
  const mergeData = (connectedBanks: string[]) => {
    setIsLoading(true);
    
    // Start with default data
    let mergedData: BankData = {
      ...defaultData,
      connectedBanks: [...connectedBanks],
      isLoaded: true
    };
    
    // Add data from each connected bank
    connectedBanks.forEach(bankId => {
      let bankSpecificData;
      
      switch(bankId) {
        case 'chase':
          bankSpecificData = chaseData;
          break;
        case 'amex':
          bankSpecificData = amexData;
          break;
        case 'vanguard':
          bankSpecificData = vanguardData;
          break;
        default:
          return;
      }
      
      // Merge accounts
      if (bankSpecificData.accounts) {
        mergedData.accounts = [...mergedData.accounts, ...bankSpecificData.accounts];
      }
      
      // Merge transactions
      if (bankSpecificData.transactions) {
        mergedData.transactions = [...mergedData.transactions, ...bankSpecificData.transactions];
      }
      
      // Merge budgets
      if (bankSpecificData.budgets) {
        // For budgets, we need to combine categories
        bankSpecificData.budgets.forEach(newBudget => {
          const existingBudgetIndex = mergedData.budgets.findIndex(
            b => b.category === newBudget.category
          );
          
          if (existingBudgetIndex >= 0) {
            // Update existing budget
            const existingBudget = mergedData.budgets[existingBudgetIndex];
            mergedData.budgets[existingBudgetIndex] = {
              ...existingBudget,
              budgeted: existingBudget.budgeted + newBudget.budgeted,
              spent: existingBudget.spent + newBudget.spent,
              percentage: Math.round(((existingBudget.spent + newBudget.spent) / 
                                     (existingBudget.budgeted + newBudget.budgeted)) * 100)
            };
          } else {
            // Add new budget category
            mergedData.budgets.push(newBudget);
          }
        });
      }
      
      // Merge upcoming bills
      if (bankSpecificData.upcomingBills) {
        mergedData.upcomingBills = [...mergedData.upcomingBills, ...bankSpecificData.upcomingBills];
      }
      
      // Merge goals
      if (bankSpecificData.goals) {
        mergedData.goals = [...mergedData.goals, ...bankSpecificData.goals];
      }
      
      // Merge investments
      if (bankSpecificData.investments) {
        mergedData.investments = [...mergedData.investments, ...bankSpecificData.investments];
      }
      
      // Merge asset allocations
      if (bankSpecificData.assetAllocations) {
        // For asset allocations, we need to recalculate percentages
        if (mergedData.assetAllocations.length === 0) {
          mergedData.assetAllocations = [...bankSpecificData.assetAllocations];
        } else {
          // This would be more complex in a real app
          mergedData.assetAllocations = bankSpecificData.assetAllocations;
        }
      }
    });
    
    // Calculate derived values
    mergedData.netWorth = mergedData.accounts.reduce((sum, account) => sum + account.balance, 0);
    
    // Calculate monthly income (positive transactions)
    mergedData.monthlyIncome = mergedData.transactions
      .filter(t => t.amount > 0)
      .reduce((sum, t) => sum + t.amount, 0);
    
    // Calculate monthly expenses (negative transactions)
    mergedData.monthlyExpenses = Math.abs(mergedData.transactions
      .filter(t => t.amount < 0)
      .reduce((sum, t) => sum + t.amount, 0));
    
    // Calculate monthly savings
    mergedData.monthlySavings = mergedData.monthlyIncome - mergedData.monthlyExpenses;
    
    // Calculate savings rate
    mergedData.savingsRate = Math.round((mergedData.monthlySavings / mergedData.monthlyIncome) * 100) || 0;
    
    // Generate insights based on the data
    mergedData.insights = [
      { 
        id: 1, 
        text: "Your dining out expenses increased by 25% compared to last month. Consider setting a budget for this category.", 
        type: "warning" 
      },
      { 
        id: 2, 
        text: "You could save $45/month by switching to a different internet provider based on current offers in your area.", 
        type: "opportunity" 
      },
      { 
        id: 3, 
        text: `Your emergency fund is ${mergedData.goals.find(g => g.name === 'Emergency Fund')?.progress || 0}% complete - great progress!`, 
        type: "positive" 
      },
    ];
    
    // Update state with merged data
    setBankData(mergedData);
    setIsLoading(false);
  };

  // Connect a bank
  const connectBank = (bankId: string) => {
    if (!bankData.connectedBanks.includes(bankId)) {
      const updatedBanks = [...bankData.connectedBanks, bankId];
      mergeData(updatedBanks);
    }
  };

  // Disconnect a bank
  const disconnectBank = (bankId: string) => {
    if (bankData.connectedBanks.includes(bankId)) {
      const updatedBanks = bankData.connectedBanks.filter(id => id !== bankId);
      mergeData(updatedBanks);
    }
  };

  // Refresh data
  const refreshData = () => {
    mergeData(bankData.connectedBanks);
  };

  // Add a new account
  const addAccount = (account: Account) => {
    setBankData(prevData => {
      const newAccounts = [...prevData.accounts, account];
      const newNetWorth = newAccounts.reduce((sum, acc) => sum + acc.balance, 0);
      
      return {
        ...prevData,
        accounts: newAccounts,
        netWorth: newNetWorth
      };
    });
  };

  // Update an existing account
  const updateAccount = (accountId: string, updates: Partial<Account>) => {
    setBankData(prevData => {
      const accountIndex = prevData.accounts.findIndex(a => a.id === accountId);
      if (accountIndex === -1) return prevData;
      
      const newAccounts = [...prevData.accounts];
      newAccounts[accountIndex] = { ...newAccounts[accountIndex], ...updates };
      
      const newNetWorth = newAccounts.reduce((sum, account) => sum + account.balance, 0);
      
      return {
        ...prevData,
        accounts: newAccounts,
        netWorth: newNetWorth
      };
    });
  };

  // Delete an account
  const deleteAccount = (accountId: string) => {
    setBankData(prevData => {
      const accountToDelete = prevData.accounts.find(a => a.id === accountId);
      if (!accountToDelete) return prevData;
      
      const newAccounts = prevData.accounts.filter(a => a.id !== accountId);
      const newNetWorth = newAccounts.reduce((sum, account) => sum + account.balance, 0);
      
      // Remove transactions associated with this account
      const newTransactions = prevData.transactions.filter(t => t.account !== accountToDelete.name);
      
      return {
        ...prevData,
        accounts: newAccounts,
        transactions: newTransactions,
        netWorth: newNetWorth
      };
    });
  };

  // Add a new transaction
  const addTransaction = (transaction: Transaction) => {
    setBankData(prevData => {
      const newTransactions = [...prevData.transactions, transaction];
      
      // Update budget for the transaction's category
      const newBudgets = [...prevData.budgets];
      const budgetIndex = newBudgets.findIndex(b => 
        b.category.toLowerCase() === transaction.category.toLowerCase()
      );
      
      if (budgetIndex >= 0 && transaction.amount < 0) {
        const budget = newBudgets[budgetIndex];
        const newSpent = budget.spent + Math.abs(transaction.amount);
        const newPercentage = Math.round((newSpent / budget.budgeted) * 100);
        
        newBudgets[budgetIndex] = {
          ...budget,
          spent: newSpent,
          percentage: newPercentage
        };
      }
      
      // Recalculate income and expenses
      const newMonthlyIncome = newTransactions
        .filter(t => t.amount > 0)
        .reduce((sum, t) => sum + t.amount, 0);
      
      const newMonthlyExpenses = Math.abs(newTransactions
        .filter(t => t.amount < 0)
        .reduce((sum, t) => sum + t.amount, 0));
      
      const newMonthlySavings = newMonthlyIncome - newMonthlyExpenses;
      const newSavingsRate = Math.round((newMonthlySavings / newMonthlyIncome) * 100) || 0;
      
      return {
        ...prevData,
        transactions: newTransactions,
        budgets: newBudgets,
        monthlyIncome: newMonthlyIncome,
        monthlyExpenses: newMonthlyExpenses,
        monthlySavings: newMonthlySavings,
        savingsRate: newSavingsRate
      };
    });
  };

  // Update an existing transaction
  const updateTransaction = (transactionId: string, updates: Partial<Transaction>) => {
    setBankData(prevData => {
      const transactionIndex = prevData.transactions.findIndex(t => t.id === transactionId);
      if (transactionIndex === -1) return prevData;
      
      const oldTransaction = prevData.transactions[transactionIndex];
      const newTransactions = [...prevData.transactions];
      newTransactions[transactionIndex] = { ...oldTransaction, ...updates };
      
      // Update budgets if category or amount changed
      const newBudgets = [...prevData.budgets];
      
      // If category changed, update both old and new category budgets
      if (updates.category && updates.category !== oldTransaction.category) {
        // Update old category budget
        const oldBudgetIndex = newBudgets.findIndex(b => 
          b.category.toLowerCase() === oldTransaction.category.toLowerCase()
        );
        
        if (oldBudgetIndex >= 0 && oldTransaction.amount < 0) {
          const oldBudget = newBudgets[oldBudgetIndex];
          const newSpent = oldBudget.spent - Math.abs(oldTransaction.amount);
          const newPercentage = Math.round((newSpent / oldBudget.budgeted) * 100);
          
          newBudgets[oldBudgetIndex] = {
            ...oldBudget,
            spent: newSpent,
            percentage: newPercentage
          };
        }
        
        // Update new category budget
        const newBudgetIndex = newBudgets.findIndex(b => 
          b.category.toLowerCase() === updates.category!.toLowerCase()
        );
        
        if (newBudgetIndex >= 0) {
          const newBudget = newBudgets[newBudgetIndex];
          const newAmount = updates.amount !== undefined ? updates.amount : oldTransaction.amount;
          
          if (newAmount < 0) {
            const newSpent = newBudget.spent + Math.abs(newAmount);
            const newPercentage = Math.round((newSpent / newBudget.budgeted) * 100);
            
            newBudgets[newBudgetIndex] = {
              ...newBudget,
              spent: newSpent,
              percentage: newPercentage
            };
          }
        }
      }
      // If only amount changed
      else if (updates.amount !== undefined && updates.amount !== oldTransaction.amount) {
        const budgetIndex = newBudgets.findIndex(b => 
          b.category.toLowerCase() === oldTransaction.category.toLowerCase()
        );
        
        if (budgetIndex >= 0) {
          const budget = newBudgets[budgetIndex];
          
          // Remove old amount and add new amount
          let newSpent = budget.spent;
          
          if (oldTransaction.amount < 0) {
            newSpent -= Math.abs(oldTransaction.amount);
          }
          
          if (updates.amount < 0) {
            newSpent += Math.abs(updates.amount);
          }
          
          const newPercentage = Math.round((newSpent / budget.budgeted) * 100);
          
          newBudgets[budgetIndex] = {
            ...budget,
            spent: newSpent,
            percentage: newPercentage
          };
        }
      }
      
      // Recalculate income and expenses
      const newMonthlyIncome = newTransactions
        .filter(t => t.amount > 0)
        .reduce((sum, t) => sum + t.amount, 0);
      
      const newMonthlyExpenses = Math.abs(newTransactions
        .filter(t => t.amount < 0)
        .reduce((sum, t) => sum + t.amount, 0));
      
      const newMonthlySavings = newMonthlyIncome - newMonthlyExpenses;
      const newSavingsRate = Math.round((newMonthlySavings / newMonthlyIncome) * 100) || 0;
      
      return {
        ...prevData,
        transactions: newTransactions,
        budgets: newBudgets,
        monthlyIncome: newMonthlyIncome,
        monthlyExpenses: newMonthlyExpenses,
        monthlySavings: newMonthlySavings,
        savingsRate: newSavingsRate
      };
    });
  };

  // Add a new budget category
  const addBudget = (budget: Budget) => {
    setBankData(prevData => ({
      ...prevData,
      budgets: [...prevData.budgets, budget]
    }));
  };

  // Update an existing budget
  const updateBudget = (category: string, updates: Partial<Budget>) => {
    setBankData(prevData => {
      const budgetIndex = prevData.budgets.findIndex(b => b.category === category);
      if (budgetIndex === -1) return prevData;
      
      const newBudgets = [...prevData.budgets];
      newBudgets[budgetIndex] = { ...newBudgets[budgetIndex], ...updates };
      
      // Recalculate percentage if budgeted amount changed
      if (updates.budgeted) {
        const spent = newBudgets[budgetIndex].spent;
        const budgeted = updates.budgeted;
        const percentage = Math.round((spent / budgeted) * 100);
        
        newBudgets[budgetIndex].percentage = percentage;
      }
      
      return {
        ...prevData,
        budgets: newBudgets
      };
    });
  };

  // Add a new goal
  const addGoal = (goal: Goal) => {
    setBankData(prevData => ({
      ...prevData,
      goals: [...prevData.goals, goal]
    }));
  };

  // Update an existing goal
  const updateGoal = (goalId: number, updates: Partial<Goal>) => {
    setBankData(prevData => {
      const goalIndex = prevData.goals.findIndex(g => g.id === goalId);
      if (goalIndex === -1) return prevData;
      
      const newGoals = [...prevData.goals];
      newGoals[goalIndex] = { ...newGoals[goalIndex], ...updates };
      
      // Recalculate progress if amounts changed
      if (updates.currentAmount || updates.targetAmount) {
        const currentAmount = updates.currentAmount || newGoals[goalIndex].currentAmount;
        const targetAmount = updates.targetAmount || newGoals[goalIndex].targetAmount;
        const progress = Math.round((currentAmount / targetAmount) * 100);
        
        newGoals[goalIndex].progress = progress;
      }
      
      return {
        ...prevData,
        goals: newGoals
      };
    });
  };

  // Add a new investment
  const addInvestment = (investment: Investment) => {
    setBankData(prevData => ({
      ...prevData,
      investments: [...prevData.investments, investment]
    }));
  };

  // Add a new bill
  const addBill = (bill: Bill) => {
    setBankData(prevData => ({
      ...prevData,
      upcomingBills: [...prevData.upcomingBills, bill]
    }));
  };

  // Delete a transaction
  const deleteTransaction = (transactionId: string) => {
    setBankData(prevData => {
      const transactionToDelete = prevData.transactions.find(t => t.id === transactionId);
      if (!transactionToDelete) return prevData;
      
      const newTransactions = prevData.transactions.filter(t => t.id !== transactionId);
      
      // Recalculate income and expenses
      const newMonthlyIncome = newTransactions
        .filter(t => t.amount > 0)
        .reduce((sum, t) => sum + t.amount, 0);
      
      const newMonthlyExpenses = Math.abs(newTransactions
        .filter(t => t.amount < 0)
        .reduce((sum, t) => sum + t.amount, 0));
      
      const newMonthlySavings = newMonthlyIncome - newMonthlyExpenses;
      const newSavingsRate = Math.round((newMonthlySavings / newMonthlyIncome) * 100) || 0;
      
      // Update budget for the transaction's category
      const newBudgets = [...prevData.budgets];
      const budgetIndex = newBudgets.findIndex(b => 
        b.category.toLowerCase() === transactionToDelete.category.toLowerCase()
      );
      
      if (budgetIndex >= 0 && transactionToDelete.amount < 0) {
        const budget = newBudgets[budgetIndex];
        const newSpent = budget.spent - Math.abs(transactionToDelete.amount);
        const newPercentage = Math.round((newSpent / budget.budgeted) * 100);
        
        newBudgets[budgetIndex] = {
          ...budget,
          spent: newSpent,
          percentage: newPercentage
        };
      }
      
      return {
        ...prevData,
        transactions: newTransactions,
        monthlyIncome: newMonthlyIncome,
        monthlyExpenses: newMonthlyExpenses,
        monthlySavings: newMonthlySavings,
        savingsRate: newSavingsRate,
        budgets: newBudgets
      };
    });
  };

  // Delete a budget category
  const deleteBudget = (category: string) => {
    setBankData(prevData => ({
      ...prevData,
      budgets: prevData.budgets.filter(b => b.category !== category)
    }));
  };

  // Delete a goal
  const deleteGoal = (goalId: number) => {
    setBankData(prevData => ({
      ...prevData,
      goals: prevData.goals.filter(g => g.id !== goalId)
    }));
  };

  // Set manual setup mode
  const setManualSetupMode = (isManual: boolean) => {
    setIsManualSetup(isManual);
  };

  // Value to be provided to consumers
  const value = {
    bankData,
    isLoading,
    isManualSetup,
    connectBank,
    disconnectBank,
    refreshData,
    addAccount,
    addTransaction,
    addBudget,
    addGoal,
    addInvestment,
    addBill,
    updateAccount,
    updateTransaction,
    updateBudget,
    updateGoal,
    deleteAccount,
    deleteTransaction,
    deleteBudget,
    deleteGoal,
    setManualSetup: setManualSetupMode
  };

  return (
    <BankDataContext.Provider value={value}>
      {children}
    </BankDataContext.Provider>
  );
};

// Custom hook to use the bank data context
export const useBankData = () => {
  const context = useContext(BankDataContext);
  if (context === undefined) {
    throw new Error('useBankData must be used within a BankDataProvider');
  }
  return context;
};