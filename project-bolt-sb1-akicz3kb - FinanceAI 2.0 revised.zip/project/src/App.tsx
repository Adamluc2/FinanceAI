import React, { useState } from 'react';
import { 
  BarChart3, 
  Wallet, 
  PiggyBank, 
  LineChart, 
  BellRing, 
  Settings, 
  LogOut,
  CreditCard,
  Landmark,
  Target,
  TrendingUp,
  DollarSign,
  AlertCircle,
  User,
  X,
  Loader
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import Transactions from './components/Transactions';
import Budget from './components/Budget';
import Goals from './components/Goals';
import Investments from './components/Investments';
import Insights from './components/Insights';
import ConnectAccounts from './components/ConnectAccounts';
import UserSettings from './components/UserSettings';
import ThemeToggle from './components/ThemeToggle';
import { useTheme } from './ThemeContext';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isConnected, setIsConnected] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const { theme } = useTheme();

  const handleLogout = () => {
    // Show loading screen
    setIsLoggingOut(true);
    
    // Simulate logout process
    setTimeout(() => {
      // In a real app, this would handle authentication logout
      setIsConnected(false);
      setActiveTab('dashboard');
      setIsLoggingOut(false);
    }, 2000);
  };

  const renderContent = () => {
    if (isLoggingOut) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen">
          <div className="animate-spin mb-4">
            <Loader size={48} className="text-indigo-600 dark:text-indigo-400" />
          </div>
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-2">Logging Out</h2>
          <p className="text-gray-600 dark:text-gray-400">Please wait while we securely log you out...</p>
        </div>
      );
    }

    if (!isConnected) {
      return <ConnectAccounts onConnect={() => setIsConnected(true)} />;
    }

    if (showSettings) {
      return <UserSettings onClose={() => setShowSettings(false)} onLogout={handleLogout} />;
    }

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'transactions':
        return <Transactions />;
      case 'budget':
        return <Budget />;
      case 'goals':
        return <Goals />;
      case 'investments':
        return <Investments />;
      case 'insights':
        return <Insights />;
      default:
        return <Dashboard />;
    }
  };

  // Mock notifications data
  const notifications = [
    { id: 1, text: "Your credit card payment is due in 3 days", time: "1 hour ago", unread: true },
    { id: 2, text: "You've exceeded your dining budget by $45", time: "3 hours ago", unread: true },
    { id: 3, text: "New investment recommendation available", time: "Yesterday", unread: false },
    { id: 4, text: "Your emergency fund goal is 83% complete", time: "2 days ago", unread: false },
  ];

  // If logging out, show only the loading screen
  if (isLoggingOut) {
    return renderContent();
  }

  // If not connected (welcome page), show only the content without sidebar
  if (!isConnected) {
    return (
      <div className="min-h-screen bg-white">
        <div className="absolute top-4 right-4">
          <ThemeToggle />
        </div>
        {renderContent()}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex transition-colors duration-200">
      {/* Sidebar */}
      <div className="w-64 bg-white dark:bg-gray-800 shadow-md hidden md:block transition-colors duration-200">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 flex items-center">
            <DollarSign className="mr-2" size={24} />
            FinanceAI
          </h1>
        </div>
        <nav className="mt-6">
          <div className="px-4 mb-2 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
            Main
          </div>
          <button
            onClick={() => {
              setActiveTab('dashboard');
              setShowSettings(false);
            }}
            className={`w-full flex items-center px-6 py-3 text-left ${
              activeTab === 'dashboard' && !showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            }`}
          >
            <BarChart3 className="mr-3" size={20} />
            Dashboard
          </button>
          <button
            onClick={() => {
              setActiveTab('transactions');
              setShowSettings(false);
            }}
            className={`w-full flex items-center px-6 py-3 text-left ${
              activeTab === 'transactions' && !showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            }`}
          >
            <Wallet className="mr-3" size={20} />
            Transactions
          </button>
          <button
            onClick={() => {
              setActiveTab('budget');
              setShowSettings(false);
            }}
            className={`w-full flex items-center px-6 py-3 text-left ${
              activeTab === 'budget' && !showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            }`}
          >
            <PiggyBank className="mr-3" size={20} />
            Budget
          </button>
          <div className="px-4 mt-6 mb-2 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
            Planning
          </div>
          <button
            onClick={() => {
              setActiveTab('goals');
              setShowSettings(false);
            }}
            className={`w-full flex items-center px-6 py-3 text-left ${
              activeTab === 'goals' && !showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            }`}
          >
            <Target className="mr-3" size={20} />
            Goals
          </button>
          <button
            onClick={() => {
              setActiveTab('investments');
              setShowSettings(false);
            }}
            className={`w-full flex items-center px-6 py-3 text-left ${
              activeTab === 'investments' && !showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            }`}
          >
            <TrendingUp className="mr-3" size={20} />
            Investments
          </button>
          <button
            onClick={() => {
              setActiveTab('insights');
              setShowSettings(false);
            }}
            className={`w-full flex items-center px-6 py-3 text-left ${
              activeTab === 'insights' && !showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            }`}
          >
            <LineChart className="mr-3" size={20} />
            Insights
          </button>
        </nav>
        <div className="absolute bottom-0 w-64 border-t border-gray-200 dark:border-gray-700">
          <button 
            onClick={() => {
              setShowSettings(true);
              setShowProfileMenu(false);
              setShowNotifications(false);
            }}
            className={`flex items-center px-6 py-3 ${
              showSettings 
                ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-r-4 border-indigo-600 dark:border-indigo-400' 
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
            } w-full text-left`}
          >
            <Settings className="mr-3" size={20} />
            Settings
          </button>
          <button 
            onClick={handleLogout}
            className="flex items-center px-6 py-3 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50 w-full text-left"
          >
            <LogOut className="mr-3" size={20} />
            Logout
          </button>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-sm z-10 transition-colors duration-200">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-bold text-indigo-600 dark:text-indigo-400 flex items-center">
            <DollarSign className="mr-2" size={20} />
            FinanceAI
          </h1>
          <div className="flex space-x-2">
            <ThemeToggle />
            <button 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 relative"
              onClick={() => {
                setShowNotifications(!showNotifications);
                setShowProfileMenu(false);
              }}
            >
              <BellRing size={20} className="text-gray-600 dark:text-gray-300" />
              {notifications.some(n => n.unread) && (
                <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
              )}
            </button>
            <button 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => {
                setShowSettings(true);
                setShowNotifications(false);
                setShowProfileMenu(false);
              }}
            >
              <Settings size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation */}
        <header className="bg-white dark:bg-gray-800 shadow-sm hidden md:block transition-colors duration-200">
          <div className="flex items-center justify-between px-6 py-4">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">
              {showSettings ? 'Settings' : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h2>
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <div className="relative">
                <button 
                  className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 relative"
                  onClick={() => {
                    setShowNotifications(!showNotifications);
                    setShowProfileMenu(false);
                  }}
                >
                  <BellRing size={20} className="text-gray-600 dark:text-gray-300" />
                  {notifications.some(n => n.unread) && (
                    <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
                  )}
                </button>
                
                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-lg z-10 overflow-hidden transition-colors duration-200">
                    <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                      <h3 className="font-semibold text-gray-800 dark:text-gray-200">Notifications</h3>
                      <button className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300">
                        <span className="text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300">Mark all as read</span>
                      </button>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.map(notification => (
                        <div 
                          key={notification.id} 
                          className={`p-4 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 ${notification.unread ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                        >
                          <div className="flex items-start">
                            <div className={`p-2 rounded-full mr-3 ${notification.unread ? 'bg-blue-100 dark:bg-blue-800/50' : 'bg-gray-100 dark:bg-gray-700'}`}>
                              <AlertCircle size={16} className={notification.unread ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'} />
                            </div>
                            <div>
                              <p className="text-sm text-gray-800 dark:text-gray-200">{notification.text}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{notification.time}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-3 text-center border-t border-gray-200 dark:border-gray-700">
                      <button className="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 font-medium">
                        View all notifications
                      </button>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="relative">
                <button 
                  className="h-8 w-8 rounded-full bg-indigo-600 dark:bg-indigo-500 flex items-center justify-center text-white font-semibold hover:bg-indigo-700 dark:hover:bg-indigo-600"
                  onClick={() => {
                    setShowProfileMenu(!showProfileMenu);
                    setShowNotifications(false);
                  }}
                >
                  U
                </button>
                
                {/* Profile Dropdown */}
                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg z-10 overflow-hidden transition-colors duration-200">
                    <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                      <p className="font-medium text-gray-800 dark:text-gray-200">User Name</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">user@example.com</p>
                    </div>
                    <div>
                      <button 
                        onClick={() => {
                          setShowSettings(true);
                          setShowProfileMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center"
                      >
                        <Settings size={16} className="mr-2 text-gray-600 dark:text-gray-400" />
                        <span className="text-gray-700 dark:text-gray-300">Settings</span>
                      </button>
                      <button 
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center"
                      >
                        <LogOut size={16} className="mr-2 text-gray-600 dark:text-gray-400" />
                        <span className="text-gray-700 dark:text-gray-300">Logout</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto mt-16 md:mt-0 bg-gray-50 dark:bg-gray-900 transition-colors duration-200" onClick={() => {
          // Close dropdowns when clicking on main content
          if (showNotifications) setShowNotifications(false);
          if (showProfileMenu) setShowProfileMenu(false);
        }}>
          {renderContent()}
        </main>

        {/* Mobile Navigation */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex justify-around transition-colors duration-200">
          <button 
            onClick={() => {
              setActiveTab('dashboard');
              setShowSettings(false);
            }} 
            className={`p-3 flex flex-col items-center ${activeTab === 'dashboard' && !showSettings ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'}`}
          >
            <BarChart3 size={20} />
            <span className="text-xs mt-1">Dashboard</span>
          </button>
          <button 
            onClick={() => {
              setActiveTab('transactions');
              setShowSettings(false);
            }} 
            className={`p-3 flex flex-col items-center ${activeTab === 'transactions' && !showSettings ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'}`}
          >
            <Wallet size={20} />
            <span className="text-xs mt-1">Transactions</span>
          </button>
          <button 
            onClick={() => {
              setActiveTab('budget');
              setShowSettings(false);
            }} 
            className={`p-3 flex flex-col items-center ${activeTab === 'budget' && !showSettings ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'}`}
          >
            <PiggyBank size={20} />
            <span className="text-xs mt-1">Budget</span>
          </button>
          <button 
            onClick={() => {
              setActiveTab('goals');
              setShowSettings(false);
            }} 
            className={`p-3 flex flex-col items-center ${activeTab === 'goals' && !showSettings ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'}`}
          >
            <Target size={20} />
            <span className="text-xs mt-1">Goals</span>
          </button>
        </nav>
      </div>
    </div>
  );
}

export default App;